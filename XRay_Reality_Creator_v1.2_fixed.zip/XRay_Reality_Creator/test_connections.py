"""Offline checks for REALITY link validation and TCP connection diagnostics."""

import base64
import socket
import unittest
from unittest import mock
from urllib.parse import urlencode

from connections import parse_reality_link, probe_public_links


CLIENT_ID = '11111111-2222-4333-8444-555555555555'
PUBLIC_KEY = base64.urlsafe_b64encode(bytes(range(32))).decode().rstrip('=')
SHORT_ID = '0011223344556677'
PARAMETERS = {
    'security': 'reality', 'encryption': 'none', 'pbk': PUBLIC_KEY,
    'fp': 'chrome', 'spx': '/', 'type': 'tcp', 'flow': 'xtls-rprx-vision',
    'sni': 'www.example.com', 'sid': SHORT_ID,
}


def link(host='127.0.0.1', port=443, **changes):
    parameters = {**PARAMETERS, **changes}
    authority = '[' + host + ']' if ':' in host else host
    return f'vless://{CLIENT_ID}@{authority}:{port}?{urlencode(parameters)}#Test'


class LinkTests(unittest.TestCase):
    def test_generated_link_fields_round_trip(self):
        self.assertEqual(parse_reality_link(link()), {
            'host': '127.0.0.1', 'port': 443, 'id': CLIENT_ID,
            'public_key': PUBLIC_KEY, 'short_id': SHORT_ID,
            'sni': 'www.example.com', 'fingerprint': 'chrome',
            'flow': 'xtls-rprx-vision', 'spider_x': '/',
        })

    def test_ipv6_raw_transport_and_uppercase_short_id(self):
        fields = parse_reality_link(link('2001:db8::1', 8443, type='raw', sid=SHORT_ID.upper()))
        self.assertEqual((fields['host'], fields['port']), ('2001:db8::1', 8443))
        self.assertEqual(fields['short_id'], SHORT_ID)

    def test_duplicate_security_and_credential_parameters_are_rejected(self):
        for key in ('pbk', 'sid', 'sni', 'security', 'flow'):
            with self.subTest(key=key), self.assertRaises(ValueError):
                original = link().partition('#')[0]
                parse_reality_link(original + '&' + urlencode({key: PARAMETERS[key]}))

    def test_invalid_public_key_is_rejected(self):
        for key in ('', 'not-a-key', PUBLIC_KEY[:-1], 'a' * 64, PUBLIC_KEY[:-1] + '$'):
            with self.subTest(key=key), self.assertRaises(ValueError):
                parse_reality_link(link(pbk=key))

    def test_invalid_short_id_is_rejected(self):
        for short_id in ('1', 'x0', '00' * 9):
            with self.subTest(short_id=short_id), self.assertRaises(ValueError):
                parse_reality_link(link(sid=short_id))

    def test_invalid_uuid_port_and_protocol_are_rejected(self):
        invalid = [link().replace(CLIENT_ID, 'not-a-uuid'),
                   link().replace('vless://', 'https://'),
                   link(port=0), link(port=65536), link(port='invalid')]
        for candidate in invalid:
            with self.subTest(candidate=candidate), self.assertRaises(ValueError):
                parse_reality_link(candidate)

    def test_incompatible_or_missing_reality_settings_are_rejected(self):
        changes = [{'security': 'tls'}, {'encryption': 'aes-128-gcm'},
                   {'type': 'ws'}, {'flow': ''}, {'sni': 'https://example.com'},
                   {'sni': 'example.com path'}]
        for change in changes:
            with self.subTest(change=change), self.assertRaises(ValueError):
                parse_reality_link(link(**change))
        for missing in ('security', 'encryption', 'pbk', 'type', 'flow', 'sni', 'sid'):
            parameters = {key: value for key, value in PARAMETERS.items() if key != missing}
            with self.subTest(missing=missing), self.assertRaises(ValueError):
                parse_reality_link(f'vless://{CLIENT_ID}@127.0.0.1:443?{urlencode(parameters)}')


class PublicProbeTests(unittest.TestCase):
    def test_real_loopback_success_has_positive_latency_and_refusal_has_none(self):
        listener = socket.socket()
        self.addCleanup(listener.close)
        listener.bind(('127.0.0.1', 0))
        listener.listen(1)
        port = listener.getsockname()[1]
        record, = probe_public_links([link(port=port)], timeout=1)
        self.assertEqual(record['port'], port)
        self.assertTrue(record['reachable'])
        self.assertGreater(record['latency_ms'], 0)
        self.assertEqual(record['error'], '')
        listener.close()
        record, = probe_public_links([link(port=port)], timeout=1)
        self.assertEqual(record['port'], port)
        self.assertFalse(record['reachable'])
        self.assertIsNone(record['latency_ms'])
        self.assertEqual(record['error'], 'refused')

    def test_timeout_dns_and_other_network_errors_do_not_look_like_zero_ping(self):
        failures = [(socket.timeout('timed out'), 'timeout'),
                    (socket.gaierror(socket.EAI_NONAME, 'name not found'), 'dns'),
                    (OSError('network unreachable'), 'network')]
        for failure, reason in failures:
            with self.subTest(reason=reason), mock.patch('socket.create_connection', side_effect=failure) as connect:
                record, = probe_public_links([link(host='server.example.com', port=8443)], timeout=2)
                connect.assert_called_once_with(('server.example.com', 8443), timeout=2)
                self.assertEqual(record, {'port': 8443, 'reachable': False,
                                          'latency_ms': None, 'error': reason})

    def test_failed_primary_probe_does_not_skip_secondary(self):
        transport = mock.MagicMock()
        with mock.patch('socket.create_connection', side_effect=[TimeoutError(), transport]) as connect:
            primary, secondary = probe_public_links([link(port=443), link(port=2053)])
        self.assertEqual(connect.call_count, 2)
        self.assertFalse(primary['reachable'])
        self.assertIsNone(primary['latency_ms'])
        self.assertTrue(secondary['reachable'])
        self.assertGreater(secondary['latency_ms'], 0)


if __name__ == '__main__':
    unittest.main()
