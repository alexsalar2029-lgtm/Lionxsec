"""Local REALITY traffic regression using a verified, caller-supplied Xray binary.

Run with XRAY_TEST_BINARY=/path/to/xray python -m unittest -v test_real_xray.
Without that variable these optional integration checks explicitly skip. All
servers, clients, TLS targets and test requests use loopback; no SSH, firewall,
systemd or public-server changes are made. OpenSSL generates a localhost SAN
certificate which is trusted through SSL_CERT_FILE, keeping TLS verification on.
"""

import http.server
import contextlib
import io
import json
import os
from pathlib import Path
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import deployment


def _free_loopback_ports(count):
    sockets = []
    try:
        for _ in range(count):
            sock = socket.socket()
            sock.bind(("127.0.0.1", 0))
            sockets.append(sock)
        return [sock.getsockname()[1] for sock in sockets]
    finally:
        for sock in sockets:
            sock.close()


class _HeadHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def handle(self):
        try:
            super().handle()
        except OSError:
            # TLS preflight and rejected REALITY fallbacks can intentionally
            # disconnect before an HTTP request reaches this local fixture.
            pass

    def do_HEAD(self):
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, *_):
        pass


class _TLSTarget(http.server.ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False

    def __init__(self, certificate, key, version=ssl.TLSVersion.TLSv1_3):
        self.tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        self.tls.minimum_version = version
        self.tls.maximum_version = version
        self.tls.set_alpn_protocols(["http/1.1"])
        self.tls.load_cert_chain(certificate, key)
        super().__init__(("127.0.0.1", 0), _HeadHandler)

    def process_request_thread(self, request, client_address):
        # Handshake in the request thread so a REALITY fallback connection cannot
        # block subsequent accepts on the TLS target.
        try:
            request.settimeout(3)
            request = self.tls.wrap_socket(request, server_side=True)
            super().process_request_thread(request, client_address)
        except (OSError, ssl.SSLError):
            request.close()


@unittest.skipUnless(os.environ.get("XRAY_TEST_BINARY"),
                     "Set XRAY_TEST_BINARY to a checksum-verified official Xray binary")
class RealXrayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.binary = str(Path(os.environ["XRAY_TEST_BINARY"]).resolve())
        if not Path(cls.binary).is_file():
            raise RuntimeError("XRAY_TEST_BINARY does not point to an existing file")
        if not shutil.which("openssl"):
            raise unittest.SkipTest("The optional local TLS fixture needs OpenSSL")
        cls.shared = tempfile.TemporaryDirectory(prefix="creator-local-tls-")
        cls.addClassCleanup(cls.shared.cleanup)
        root = Path(cls.shared.name)
        cls.certificate = root / "localhost.crt"
        cls.key = root / "localhost.key"
        subprocess.run([
            "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
            "-keyout", str(cls.key), "-out", str(cls.certificate), "-days", "1",
            "-subj", "/CN=localhost", "-addext", "subjectAltName=DNS:localhost",
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        cls.target = _TLSTarget(str(cls.certificate), str(cls.key))
        cls.addClassCleanup(cls.target.server_close)
        cls.thread = threading.Thread(target=cls.target.serve_forever, daemon=True)
        cls.thread.start()
        cls.addClassCleanup(cls.target.shutdown)
        cls.test_url = f"https://localhost:{cls.target.server_port}/health"

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="creator-real-xray-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config_path = self.root / "config.json"
        self.links_path = self.root / "links.txt"
        self.ports = _free_loopback_ports(2)
        (self.root / "ports.json").write_text(json.dumps({
            "listen": "127.0.0.1", "ports": self.ports,
        }), encoding="utf-8")
        # Execute the real generation payload, rather than recreating key/link
        # generation in this fixture. Do not execute the deployment shell script.
        script = deployment.build_deployment_script("127.0.0.1", "localhost", "LocalTest")
        payload = script.split("python3 - <<'CREATOR_PY'\n", 1)[1].split("\nCREATOR_PY\n", 1)[0]
        env = {**os.environ, "XRAY_BIN": self.binary, "CREATOR_TMP": str(self.root),
               "CREATOR_HOST": "127.0.0.1", "CREATOR_SNI": "localhost",
               "CREATOR_NAME": "LocalTest"}
        result = subprocess.run([sys.executable, "-c", payload], env=env,
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.config = json.loads(self.config_path.read_text(encoding="utf-8"))
        for inbound in self.config["inbounds"]:
            reality = inbound["streamSettings"]["realitySettings"]
            reality.pop("target", None)
            reality["dest"] = f"127.0.0.1:{self.target.server_port}"
        self.config_path.write_text(json.dumps(self.config), encoding="utf-8")
        self.server = None
        self.addCleanup(self._stop_server)

    def _stop_server(self):
        if self.server is None:
            return
        self.server.terminate()
        try:
            self.server.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.server.kill()
            self.server.wait(timeout=5)
        self.server = None

    def _start_server(self, actual_config=None):
        path = self.config_path
        if actual_config is not None:
            path = self.root / "running-config.json"
            path.write_text(json.dumps(actual_config), encoding="utf-8")
        result = subprocess.run([self.binary, "run", "-test", "-config", str(path)],
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.server = subprocess.Popen([self.binary, "run", "-config", str(path)],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            self.assertIsNone(self.server.poll(), "Local Xray server exited before listening")
            try:
                for port in self.ports:
                    with socket.create_connection(("127.0.0.1", port), timeout=.1):
                        pass
                return
            except OSError:
                time.sleep(.03)
        self.fail("Local Xray did not listen on both test ports")

    def _verify(self, timeout=4):
        from connections import verify_reality_connections
        with mock.patch.dict(os.environ, {
            "SSL_CERT_FILE": str(self.certificate), "NO_PROXY": "*", "no_proxy": "*",
            "HTTP_PROXY": "http://127.0.0.1:1", "HTTPS_PROXY": "http://127.0.0.1:1",
            "http_proxy": "http://127.0.0.1:1", "https_proxy": "http://127.0.0.1:1",
        }):
            return verify_reality_connections(self.binary, str(self.config_path),
                                             str(self.links_path), timeout=timeout,
                                             test_url=self.test_url)

    def _check_target(self, target=None, trusted=True):
        from connections import check_reality_target
        target = target or self.target
        original_connect = socket.create_connection

        def redirected_connect(address, *args, **kwargs):
            self.assertEqual(address, ("localhost", 443), "Unexpected preflight destination")
            return original_connect(("127.0.0.1", target.server_port), *args, **kwargs)

        with mock.patch.dict(os.environ):
            if trusted:
                os.environ["SSL_CERT_FILE"] = str(self.certificate)
            else:
                os.environ.pop("SSL_CERT_FILE", None)
                os.environ.pop("SSL_CERT_DIR", None)
            with mock.patch("socket.create_connection", side_effect=redirected_connect) as connect:
                check_reality_target("localhost", timeout=3)
                connect.assert_called_once_with(("localhost", 443), timeout=3)

    def _alter_links(self, field, value):
        lines = []
        for line in self.links_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("LINK_"):
                label, link = line.split("=", 1)
                parsed = urlsplit(link)
                query = dict(parse_qsl(parsed.query))
                query[field] = value
                line = label + "=" + urlunsplit(parsed._replace(query=urlencode(query)))
            lines.append(line)
        self.links_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def test_generated_links_transfer_verified_https_on_both_ports(self):
        self._start_server()
        results = self._verify(timeout=8)
        self.assertEqual({item["port"] for item in results}, set(self.ports))
        self.assertEqual(len(results), 2)
        for result in results:
            self.assertGreater(result["latency_ms"], 0)

    def test_preflight_accepts_verified_tls13_and_emits_marker(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            self._check_target()
        self.assertEqual(output.getvalue(), "TARGET_TLS_VERIFIED=TLSv1.3\n")

    def test_preflight_rejects_untrusted_tls13_certificate(self):
        with self.assertRaisesRegex(RuntimeError, "CERTIFICATE_VERIFY_FAILED|certificate verify failed"):
            self._check_target(trusted=False)

    def test_preflight_rejects_tls12_only_target(self):
        target = _TLSTarget(str(self.certificate), str(self.key), version=ssl.TLSVersion.TLSv1_2)
        self.addCleanup(target.server_close)
        thread = threading.Thread(target=target.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(target.shutdown)
        with self.assertRaisesRegex(RuntimeError, "REALITY target check failed"):
            self._check_target(target)

    def test_wrong_public_key_cannot_report_success(self):
        self._start_server()
        keys = subprocess.run([self.binary, "x25519"], check=True,
                              capture_output=True, text=True, timeout=10).stdout
        _, different_public = deployment.parse_x25519_keys(keys)
        self._alter_links("pbk", different_public)
        with self.assertRaises(RuntimeError):
            self._verify()

    def test_wrong_short_id_cannot_report_success(self):
        self._start_server()
        self._alter_links("sid", "abcdef0123456789")
        with self.assertRaises(RuntimeError):
            self._verify()

    def test_open_ports_with_stale_running_credentials_are_rejected(self):
        actual = json.loads(json.dumps(self.config))
        for inbound in actual["inbounds"]:
            inbound["streamSettings"]["realitySettings"]["shortIds"] = ["9876543210abcdef"]
        self._start_server(actual)
        with self.assertRaises(RuntimeError):
            self._verify()

    def test_https_target_certificate_must_be_trusted(self):
        from connections import verify_reality_connections
        self._start_server()
        with mock.patch.dict(os.environ):
            os.environ.pop("SSL_CERT_FILE", None)
            os.environ.pop("SSL_CERT_DIR", None)
            with self.assertRaisesRegex(RuntimeError, "CERTIFICATE_VERIFY_FAILED|certificate verify failed"):
                verify_reality_connections(self.binary, str(self.config_path),
                                          str(self.links_path), timeout=4,
                                          test_url=self.test_url)


if __name__ == "__main__":
    unittest.main()
