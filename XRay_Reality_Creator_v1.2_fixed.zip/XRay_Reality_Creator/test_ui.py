"""Headless checks of result handling; run with requirements.txt installed."""

import base64
import importlib.util
from types import SimpleNamespace
import unittest
from unittest import mock

DEPENDENCIES = ('tkinter', 'customtkinter', 'paramiko', 'pyperclip', 'PIL', 'qrcode')
UI_AVAILABLE = all(importlib.util.find_spec(name) for name in DEPENDENCIES)


@unittest.skipUnless(UI_AVAILABLE, 'Install requirements.txt to test UI result handling')
class ResultTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app
        cls.app = app

    def setUp(self):
        self.window = SimpleNamespace(**{name: mock.Mock() for name in (
            'lbl_status', 'lbl_result', 'btn_copy', 'prog_bar', 'txt_result',
            'append_log', 'save_to_history_db')})
        key = base64.urlsafe_b64encode(bytes(range(32))).decode().rstrip('=')
        self.links = [
            f'vless://11111111-2222-4333-8444-555555555555@192.0.2.10:{port}'
            f'?security=reality&encryption=none&pbk={key}&type=tcp&flow=xtls-rprx-vision'
            '&sni=www.example.com&sid=0011223344556677#LocalTest'
            for port in (443, 2053)
        ]
        self.clipboard = mock.patch.object(self.app.pyperclip, 'copy').start()
        self.messages = mock.patch.object(self.app, 'messagebox').start()
        self.addCleanup(mock.patch.stopall)

    def complete(self, reachable=(True, True)):
        checks = [{'port': port, 'reachable': status,
                   'latency_ms': 10 if status else None, 'error': '' if status else 'timeout'}
                  for port, status in zip((443, 2053), reachable)]
        self.app.XRayCreatorApp.deployment_succeeded(
            self.window, '192.0.2.10', 'LocalTest', *self.links, 'www.example.com', checks)

    def test_verified_server_and_reachable_ports_show_result(self):
        self.complete()
        self.messages.showinfo.assert_called_once()
        self.messages.showwarning.assert_not_called()
        self.clipboard.assert_called_once_with(self.links[0])
        self.window.txt_result.insert.assert_called_once_with('1.0', '\n\n'.join(self.links))

    def test_all_public_ports_blocked_show_warning_and_keep_links(self):
        self.complete((False, False))
        self.messages.showwarning.assert_called_once()
        self.messages.showinfo.assert_not_called()
        self.assertIn('در دسترس نیست', self.window.lbl_status.configure.call_args.kwargs['text'])
        self.window.txt_result.insert.assert_called_once()

    def test_only_reachable_secondary_becomes_display_clipboard_and_history_primary(self):
        self.complete((False, True))
        self.clipboard.assert_called_once_with(self.links[1])
        self.window.txt_result.insert.assert_called_once_with('1.0', '\n\n'.join(reversed(self.links)))
        self.assertEqual(self.window.save_to_history_db.call_args.args[2], self.links[1])
        self.assertIn('2053', self.window.btn_copy.configure.call_args.kwargs['text'])
        self.messages.showwarning.assert_called_once()

    def test_clipboard_failure_does_not_hide_verified_links(self):
        self.clipboard.side_effect = RuntimeError('No clipboard backend')
        self.complete()
        self.window.txt_result.insert.assert_called_once()
        self.messages.showinfo.assert_called_once()
        self.assertIn('کپی خودکار انجام نشد', self.messages.showinfo.call_args.args[1])


if __name__ == '__main__':
    unittest.main()
