"""REALITY configuration checks and bounded connectivity diagnostics.

Socket latency is labelled TCP latency, never a successful proxy/ICMP ping.
"""


def parse_reality_link(link):
    import base64
    import re
    import uuid
    from urllib.parse import parse_qs, unquote, urlsplit

    parsed = urlsplit(link.strip())
    if parsed.scheme != 'vless' or not parsed.hostname or not parsed.username:
        raise ValueError('لینک VLESS معتبر نیست.')
    port = parsed.port
    if port is None or not 1 <= port <= 65535:
        raise ValueError('پورت لینک VLESS معتبر نیست.')
    client_id = str(uuid.UUID(unquote(parsed.username)))
    query = parse_qs(parsed.query, keep_blank_values=True)
    if any(len(values) != 1 for values in query.values()):
        raise ValueError('پارامتر تکراری در لینک VLESS وجود دارد.')
    params = {key: values[0] for key, values in query.items()}
    transport = params.get('type')
    if transport in ('raw', 'tcp'):
        transport = 'tcp'
    elif transport in ('xhttp', 'splithttp'):
        transport = 'xhttp'
    if (params.get('security') != 'reality'
            or params.get('encryption') != 'none'
            or transport not in ('tcp', 'xhttp')):
        raise ValueError('لینک باید VLESS/REALITY با انتقال TCP یا XHTTP باشد.')
    flow = params.get('flow', '')
    if transport == 'tcp' and flow != 'xtls-rprx-vision':
        raise ValueError('لینک TCP این برنامه باید جریان Vision داشته باشد.')
    if transport == 'xhttp' and flow:
        raise ValueError('XHTTP با جریان Vision سازگار نیست؛ پارامتر flow باید خالی باشد.')
    mode, path = '', ''
    if transport == 'xhttp':
        mode, path = params.get('mode', 'auto'), params.get('path', '/')
        if mode not in ('auto', 'packet-up', 'stream-up', 'stream-one'):
            raise ValueError('حالت XHTTP معتبر نیست.')
        if not path.startswith('/') or any(char in path for char in '\r\n\t\0 #?'):
            raise ValueError('مسیر XHTTP باید با / شروع شود و فقط مسیر باشد.')
    public_key = params.get('pbk', '')
    if not re.fullmatch(r'[A-Za-z0-9_-]{43}=?', public_key):
        raise ValueError('کلید عمومی REALITY معتبر نیست.')
    decoded = base64.b64decode(public_key + '=' * (-len(public_key) % 4), altchars=b'-_', validate=True)
    if len(decoded) != 32:
        raise ValueError('طول کلید عمومی REALITY معتبر نیست.')
    short_id = params.get('sid', '')
    if not re.fullmatch(r'(?:[0-9a-fA-F]{2}){0,8}', short_id) or 'sid' not in params:
        raise ValueError('Short ID باید حداکثر ۱۶ رقم هگز با طول زوج باشد.')
    sni = params.get('sni', '')
    if not sni or any(char in sni for char in '/:@[] \t\r\n'):
        raise ValueError('دامنه SNI لینک معتبر نیست.')
    return {'host': parsed.hostname, 'port': port, 'id': client_id,
            'public_key': public_key, 'short_id': short_id.lower(),
            'sni': sni, 'fingerprint': params.get('fp') or 'chrome',
            'flow': flow, 'spider_x': params.get('spx', '/'),
            'transport': transport, 'mode': mode, 'path': path}


def check_reality_target(sni, timeout=12, require_h2=False):
    """Require a certificate-verified TLS 1.3 target reachable from the VPS."""
    import socket
    import ssl

    context = ssl.create_default_context()
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.set_alpn_protocols(['h2', 'http/1.1'])
    try:
        with socket.create_connection((sni, 443), timeout=timeout) as transport:
            with context.wrap_socket(transport, server_hostname=sni) as secured:
                if secured.version() != 'TLSv1.3':
                    raise RuntimeError('Target did not negotiate TLS 1.3.')
                if require_h2 and secured.selected_alpn_protocol() != 'h2':
                    raise RuntimeError('XHTTP target did not negotiate HTTP/2 (h2). Choose another SNI.')
    except (OSError, RuntimeError) as exc:
        raise RuntimeError(
            'REALITY target check failed: ' + sni + ':443. '
            'Check DNS, server egress, TLS 1.3 and the target certificate. ' + str(exc)
        ) from exc
    print('TARGET_TLS_VERIFIED=TLSv1.3', flush=True)
    if require_h2:
        print('TARGET_ALPN_VERIFIED=h2', flush=True)


def verify_reality_connections(xray_bin, config_path, links_path, timeout=20, test_url=None):
    """Run the actual generated credentials through each server inbound.

    The temporary client lives in a private directory and binds only loopback.
    test_url is an explicit local integration-test fixture override; production
    uses the selected SNI's HTTPS endpoint with certificate validation enabled.
    """
    import json
    import socket
    import ssl
    import subprocess
    import tempfile
    import time
    from pathlib import Path
    from urllib.error import HTTPError, URLError
    from urllib.request import (build_opener, HTTPHandler, HTTPRedirectHandler,
                                HTTPSHandler, ProxyHandler, Request)

    config = json.loads(Path(config_path).read_text(encoding='utf-8'))
    inbounds = {inbound['port']: inbound for inbound in config['inbounds']}
    links = []
    for line in Path(links_path).read_text(encoding='utf-8').splitlines():
        if line.startswith(('LINK_PRIMARY=', 'LINK_SECONDARY=')):
            try:
                links.append(parse_reality_link(line.partition('=')[2]))
            except ValueError as exc:
                raise RuntimeError('Generated REALITY link is invalid: ' + str(exc)) from exc
    if len(links) != 2 or {link['port'] for link in links} != set(inbounds):
        raise RuntimeError('REALITY connection test needs the two matching generated links.')

    class NoRedirects(HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    results = []
    with tempfile.TemporaryDirectory(prefix='xray-connection-test-') as directory:
        for link in links:
            port = link['port']
            inbound = inbounds[port]
            stream = inbound['streamSettings']
            reality = stream['realitySettings']
            clients = inbound['settings']['clients']
            if (link['sni'] not in reality['serverNames']
                    or link['short_id'] not in reality['shortIds']
                    or not any(client['id'] == link['id'] and client.get('flow', '') == link['flow']
                               for client in clients)):
                raise RuntimeError('Generated link does not match server credentials on port ' + str(port))
            server_transport = stream.get('network', 'tcp')
            server_transport = 'xhttp' if server_transport in ('xhttp', 'splithttp') else server_transport
            server_transport = 'tcp' if server_transport in ('raw', 'tcp') else server_transport
            if server_transport != link['transport']:
                raise RuntimeError('Generated link transport does not match server on port ' + str(port))
            if link['transport'] == 'xhttp':
                xhttp = stream.get('xhttpSettings', stream.get('splithttpSettings', {}))
                if (xhttp.get('path', '/') != link['path']
                        or xhttp.get('mode', 'auto') not in ('auto', link['mode'])):
                    raise RuntimeError('Generated XHTTP link path/mode does not match server on port ' + str(port))
            listen = inbound.get('listen', '0.0.0.0')
            server_host = '::1' if ':' in listen else '127.0.0.1'
            with socket.socket() as reserve:
                reserve.bind(('127.0.0.1', 0))
                proxy_port = reserve.getsockname()[1]
            client_config = {
                'log': {'loglevel': 'warning'},
                'inbounds': [{'listen': '127.0.0.1', 'port': proxy_port,
                              'protocol': 'http', 'settings': {}}],
                'outbounds': [{
                    'protocol': 'vless',
                    'settings': {'vnext': [{'address': server_host, 'port': port,
                                          'users': [{'id': link['id'], 'encryption': 'none',
                                                     'flow': link['flow']}]}]},
                    'streamSettings': {
                        'network': link['transport'], 'security': 'reality',
                        'realitySettings': {'serverName': link['sni'], 'publicKey': link['public_key'],
                                            'shortId': link['short_id'], 'fingerprint': link['fingerprint'],
                                            'spiderX': link['spider_x']},
                    },
                }],
            }
            if link['transport'] == 'xhttp':
                client_config['outbounds'][0]['settings']['vnext'][0]['users'][0].pop('flow', None)
                client_config['outbounds'][0]['streamSettings']['xhttpSettings'] = {
                    'path': link['path'], 'mode': link['mode'],
                }
            path = Path(directory) / ('client-' + str(port) + '.json')
            path.write_text(json.dumps(client_config), encoding='utf-8')
            process = subprocess.Popen([str(xray_bin), 'run', '-config', str(path)],
                                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL)
            try:
                deadline = time.monotonic() + min(timeout, 5)
                while True:
                    if process.poll() is not None:
                        raise RuntimeError('Temporary Xray client failed to start; check the installed core version.')
                    try:
                        with socket.create_connection(('127.0.0.1', proxy_port), timeout=0.2):
                            break
                    except OSError:
                        if time.monotonic() >= deadline:
                            raise RuntimeError('Temporary Xray client did not open its loopback HTTP port.')
                        time.sleep(0.05)
                # These handlers always use the temporary proxy, even if the
                # machine inherited no_proxy=localhost or other proxy settings.
                class TunnelHTTP(HTTPHandler):
                    def http_open(self, request):
                        request.set_proxy('127.0.0.1:' + str(proxy_port), 'http')
                        return super().http_open(request)

                class TunnelHTTPS(HTTPSHandler):
                    def https_open(self, request):
                        request.set_proxy('127.0.0.1:' + str(proxy_port), 'http')
                        return super().https_open(request)

                opener = build_opener(ProxyHandler({}), TunnelHTTP(),
                                      TunnelHTTPS(context=ssl.create_default_context()), NoRedirects())
                url = test_url or 'https://' + link['sni'] + '/'
                if not url.startswith('https://'):
                    raise ValueError('Connection tests require HTTPS.')
                started = time.monotonic()
                try:
                    with opener.open(Request(url, method='HEAD'), timeout=timeout) as response:
                        status = response.status
                except HTTPError as response:
                    status = response.code
                    response.close()
                if not 200 <= status < 600:
                    raise RuntimeError('HTTPS probe returned status ' + str(status))
                latency_ms = max(1, round((time.monotonic() - started) * 1000))
                results.append({'port': port, 'latency_ms': latency_ms})
                print(f'REALITY_PORT_VERIFIED={port}:{latency_ms}', flush=True)
            except (OSError, ValueError, RuntimeError, URLError) as exc:
                raise RuntimeError(
                    f'REALITY handshake failed on port {port}. '
                    'Check the service config, UUID, public key, short ID, SNI and server egress. ' + str(exc)
                ) from exc
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=5)
    return results


def probe_public_links(links, timeout=5):
    """Check TCP from the user's machine; this is not a proxy handshake test."""
    import socket
    import time

    results = []
    for link in links:
        fields = parse_reality_link(link)
        started = time.monotonic()
        try:
            with socket.create_connection((fields['host'], fields['port']), timeout=timeout):
                pass
            results.append({'port': fields['port'], 'reachable': True,
                            'latency_ms': max(1, round((time.monotonic() - started) * 1000)), 'error': ''})
        except OSError as exc:
            reason = ('timeout' if isinstance(exc, TimeoutError) else
                      'refused' if isinstance(exc, ConnectionRefusedError) else
                      'dns' if isinstance(exc, socket.gaierror) else 'network')
            results.append({'port': fields['port'], 'reachable': False,
                            'latency_ms': None, 'error': reason})
    return results
