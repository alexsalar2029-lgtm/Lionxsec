"""Deployment helpers independent of the desktop UI."""

import codecs
import inspect
import ipaddress
import re
import shlex
import time
from urllib.parse import urlsplit
from connections import check_reality_target, parse_reality_link, verify_reality_connections


def parse_x25519_keys(output):
    """Read legacy and current Xray CLI labels; never use Hash32 as pbk."""
    import base64
    import re

    private = re.search(r"^\s*Private\s*Key\s*:\s*(\S+)\s*$", output, re.I | re.M)
    public = re.search(
        r"^\s*(?:Public\s*Key|Password(?:\s*\(\s*Public\s*Key\s*\))?)\s*:\s*(\S+)\s*$",
        output, re.I | re.M,
    )
    if not private or not public:
        raise ValueError("خروجی xray x25519 فاقد کلید خصوصی یا Password/PublicKey است.")
    keys = (private.group(1), public.group(1))
    for key in keys:
        if not re.fullmatch(r"[A-Za-z0-9_-]{43}=?", key):
            raise ValueError("قالب کلید X25519 معتبر نیست.")
        if len(base64.b64decode(key + "=" * (-len(key) % 4), altchars=b"-_", validate=True)) != 32:
            raise ValueError("طول کلید X25519 معتبر نیست.")
    return keys


def normalize_host(value, allow_ip=True):
    value = value.strip()
    try:
        address = ipaddress.ip_address(value.strip("[]"))
    except ValueError:
        try:
            value = value.rstrip(".").encode("idna").decode("ascii").lower()
        except UnicodeError as exc:
            raise ValueError("دامنه واردشده معتبر نیست.") from exc
        labels = value.split(".")
        if len(value) > 253 or any(
            not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
            for label in labels
        ):
            raise ValueError("آدرس سرور یا SNI باید فقط آی‌پی یا نام دامنه باشد؛ بدون https:// یا مسیر.")
        return value
    if not allow_ip:
        raise ValueError("برای SNI یک نام دامنه وارد کنید، نه آی‌پی.")
    return str(address)


def select_available_ports(ssh_port, candidates=(443, 2053, 2083, 8443, 9443, 10443, 11443), on_skip=None):
    """Probe wildcard TCP bindings, including IPv6; never take the SSH port."""
    import errno
    import socket

    family, listen = socket.AF_INET, "0.0.0.0"
    if socket.has_ipv6:
        try:
            with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as probe:
                probe.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
                probe.bind(("::", 0))
            family, listen = socket.AF_INET6, "::"
        except OSError:
            pass
    selected, held = [], []
    try:
        for port in dict.fromkeys(candidates):
            if port == int(ssh_port):
                if on_skip:
                    on_skip(port, "SSH")
                continue
            probe = socket.socket(family, socket.SOCK_STREAM)
            try:
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                if family == socket.AF_INET6:
                    probe.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
                probe.bind((listen, port))
                probe.listen(1)
            except OSError as exc:
                probe.close()
                if exc.errno not in (errno.EADDRINUSE, errno.EACCES):
                    raise RuntimeError(f"Could not check TCP port {port}: {exc}") from exc
                if on_skip:
                    on_skip(port, "busy" if exc.errno == errno.EADDRINUSE else "permission")
                continue
            held.append(probe)
            selected.append(port)
            if len(selected) == 2:
                return listen, selected
        raise RuntimeError("No two free TCP ports found among: " + ", ".join(map(str, candidates)))
    finally:
        for probe in held:
            probe.close()


def connection_port(link):
    """Read the actual port shown in a generated connection link."""
    parsed = urlsplit(link)
    if parsed.scheme != "vless" or not parsed.hostname or not parsed.username or not parsed.port:
        raise ValueError("لینک VLESS یا پورت آن معتبر نیست.")
    return parsed.port


def build_reality_bundle(host, sni, name, listen, ports, private_key, public_key,
                         client_id, short_id, method="tcp", xhttp_path=None):
    """Build matching server settings and share links for two REALITY profiles.

    This helper is deliberately self-contained so its exact implementation can
    also run on the remote machine before the staged configuration is installed.
    """
    import secrets
    from urllib.parse import quote, urlencode

    if method not in ("tcp", "mixed", "xhttp"):
        raise ValueError("روش اتصال باید tcp، mixed یا xhttp باشد.")
    ports = list(ports)
    if (len(ports) != 2 or any(isinstance(port, bool) or not isinstance(port, int)
                             or not 1 <= port <= 65535 for port in ports)
            or ports[0] == ports[1]):
        raise ValueError("دو پورت متفاوت و معتبر برای اتصال لازم است.")
    if xhttp_path is None:
        xhttp_path = "/" + secrets.token_hex(8)
    if (not isinstance(xhttp_path, str) or not xhttp_path.startswith("/")
            or any(character in xhttp_path for character in "\r\n\t\0 #?")):
        raise ValueError("مسیر XHTTP باید با / شروع شود و فاقد نویسهٔ کنترلی باشد.")
    # Accept both forms so callers never introduce a second IPv6 bracket pair.
    host = host[1:-1] if host.startswith("[") and host.endswith("]") else host
    link_host = f"[{host}]" if ":" in host else host
    networks = {
        "tcp": ("tcp", "tcp"),
        "mixed": ("tcp", "xhttp"),
        "xhttp": ("xhttp", "xhttp"),
    }[method]
    inbounds, links = [], ["PORTS=" + ",".join(map(str, ports))]
    for role, port, network in zip(("PRIMARY", "SECONDARY"), ports, networks):
        client = {"id": client_id, "level": 0}
        stream = {
            "network": network,
            "security": "reality",
            "realitySettings": {
                "show": False, "dest": sni + ":443", "xver": 0,
                "serverNames": [sni], "privateKey": private_key,
                "shortIds": [short_id],
            },
        }
        query = {
            "security": "reality", "encryption": "none", "pbk": public_key,
            "fp": "chrome", "spx": "/", "type": network,
            "sni": sni, "sid": short_id,
        }
        if network == "tcp":
            client["flow"] = "xtls-rprx-vision"
            query.update({"headerType": "none", "flow": "xtls-rprx-vision"})
            transport_label = "TCP-Vision"
        else:
            # Vision is a TCP flow and must not be attached to an XHTTP user.
            stream["xhttpSettings"] = {"path": xhttp_path, "mode": "auto"}
            query.update({"path": xhttp_path, "mode": "auto"})
            transport_label = "XHTTP"
        inbounds.append({
            "listen": listen, "port": port, "protocol": "vless",
            "settings": {"clients": [client], "decryption": "none"},
            "streamSettings": stream,
        })
        tag = quote(f"{name or 'HighSpeed-Reality'}-{transport_label}-Port{port}", safe="")
        links.append(
            f"LINK_{role}=vless://{client_id}@{link_host}:{port}?{urlencode(query)}#{tag}"
        )
    return {
        "config": {
            "log": {"loglevel": "warning"}, "inbounds": inbounds,
            "outbounds": [{"protocol": "freedom", "settings": {}}],
        },
        "links": links,
    }


def build_deployment_script(host, sni, name, ssh_port=22, method="tcp"):
    host = normalize_host(host)
    sni = normalize_host(sni, allow_ip=False)
    if not 1 <= int(ssh_port) <= 65535:
        raise ValueError("پورت SSH باید بین ۱ و ۶۵۵۳۵ باشد.")
    if method not in ("tcp", "mixed", "xhttp"):
        raise ValueError("روش اتصال باید tcp، mixed یا xhttp باشد.")
    name = name.strip() or "HighSpeed-Reality"
    replacements = {
        "HOST": shlex.quote(host),
        "SNI": shlex.quote(sni),
        "NAME": shlex.quote(name),
        "SSH_PORT": str(int(ssh_port)),
        "METHOD": shlex.quote(method),
        "KEY_PARSER": inspect.getsource(parse_x25519_keys),
        "BUNDLE_BUILDER": inspect.getsource(build_reality_bundle),
        "PORT_SELECTOR": inspect.getsource(select_available_ports),
        "TARGET_CHECK": inspect.getsource(check_reality_target),
        "CONNECTION_VERIFIER": inspect.getsource(parse_reality_link) + '\n' + inspect.getsource(verify_reality_connections),
    }
    return re.sub(r"__(HOST|SNI|NAME|SSH_PORT|METHOD|KEY_PARSER|BUNDLE_BUILDER|PORT_SELECTOR|TARGET_CHECK|CONNECTION_VERIFIER)__", lambda m: replacements[m[1]], REMOTE_SCRIPT)


def run_remote_script(client, script, on_output=None, timeout=900):
    """Drain stdout and stderr together so a full SSH buffer cannot deadlock."""
    stdin, stdout, stderr = client.exec_command("bash -s", timeout=30)
    channel = stdout.channel
    buffers = {"stdout": "", "stderr": ""}
    decoders = {key: codecs.getincrementaldecoder("utf-8")("replace") for key in buffers}
    try:
        stdin.write(script)
        stdin.flush()
        stdin.channel.shutdown_write()
        deadline = time.monotonic() + timeout
        while True:
            received = False
            for key, ready, receive in (
                ("stdout", channel.recv_ready, channel.recv),
                ("stderr", channel.recv_stderr_ready, channel.recv_stderr),
            ):
                if ready():
                    text = decoders[key].decode(receive(32768))
                    buffers[key] = (buffers[key] + text)[-524288:]
                    if text and on_output:
                        on_output(text)
                    received = True
            if channel.exit_status_ready() and not channel.recv_ready() and not channel.recv_stderr_ready():
                break
            if time.monotonic() >= deadline:
                tail = diagnostic_output(buffers["stdout"], buffers["stderr"])
                raise TimeoutError("زمان اجرای نصب تمام شد. آخرین گزارش سرور:\n" + tail)
            if not received:
                time.sleep(0.05)
        for key, decoder in decoders.items():
            buffers[key] += decoder.decode(b"", final=True)
        return channel.recv_exit_status(), buffers["stdout"], buffers["stderr"]
    finally:
        channel.close()


def diagnostic_output(output, errors):
    lines = [line for line in (output + "\n" + errors).splitlines() if not line.startswith("LINK_")]
    return "\n".join(lines[-70:])[-7000:]


def deployment_error_summary(details):
    if "XHTTP target did not negotiate HTTP/2" in details:
        return "دامنه SNI برای XHTTP باید TLS 1.3 و HTTP/2 داشته باشد. دامنهٔ انتخاب‌شده HTTP/2 را تأیید نکرد؛ دامنهٔ مناسب دیگری انتخاب کنید."
    lowered = details.lower()
    if "xhttp" in lowered and any(message in lowered for message in (
        "unknown transport", "invalid transport", "unsupported transport",
        "transport not registered", "xhttp is not supported",
    )):
        return "نسخهٔ Xray نصب‌شده از XHTTP پشتیبانی نمی‌کند. هستهٔ Xray سرور را با روش رسمی به نسخهٔ جدید ارتقا دهید؛ سپس دوباره نصب کنید یا روش TCP را انتخاب کنید."
    if "REALITY target check failed" in details:
        return "دامنه SNI از سرور با TLS 1.3 قابل اتصال نیست. DNS، دسترسی اینترنت سرور و گواهی دامنه را بررسی کنید یا دامنه SNI دیگری انتخاب کنید."
    if "REALITY handshake failed" in details or "Generated link does not match" in details:
        return "پورت باز است، اما اتصال واقعی REALITY برقرار نشد. تنظیمات بارگذاری‌شدهٔ سرویس، کلیدها، SNI و دسترسی اینترنت سرور باید بررسی شوند. کانفیگ قبلی در صورت امکان بازیابی شده است."
    if "No two free TCP ports" in details:
        return "دو پورت آزاد برای Xray پیدا نشد. شمارهٔ پورت‌های اشغال‌شده در کادر گزارش آمده است."
    if "bind: address already in use" in details:
        return "پورت انتخاب‌شده هنگام راه‌اندازی اشغال شده است. شمارهٔ پورت و جزئیات در کادر گزارش آمده است."
    if "Xray is not listening on selected TCP ports" in details:
        return "سرویس روی پورت‌های انتخاب‌شده گوش نمی‌دهد. تنظیمات سرویس و گزارش باید بررسی شوند."
    lines = [line.strip() for line in details.splitlines() if line.strip()]
    summary = lines[0] if lines else "عملیات کامل نشد."
    error_line = next((line for line in reversed(lines) if line.startswith("ERROR:")), "")
    if error_line and error_line != summary:
        summary += "\n" + error_line
    return summary[:650]


def parse_deployment_result(exit_code, output, errors=""):
    fields = {}
    for line in output.splitlines():
        key, separator, value = line.partition("=")
        if separator and key in ("SERVICE_STATUS", "PORTS", "HANDSHAKE_VERIFIED", "LINK_PRIMARY", "LINK_SECONDARY", "LINK_2053", "LINK_443"):
            fields[key] = value.strip()
    if any(key in fields for key in ("PORTS", "LINK_PRIMARY", "LINK_SECONDARY")):
        primary, secondary = fields.get("LINK_PRIMARY", ""), fields.get("LINK_SECONDARY", "")
        port_text = fields.get("PORTS", "")
    else:
        primary, secondary = fields.get("LINK_2053", ""), fields.get("LINK_443", "")
        port_text = "2053,443"
    try:
        ports = [int(port) for port in port_text.split(",")]
        valid_links = (
            len(ports) == 2 and ports[0] != ports[1]
            and [connection_port(primary), connection_port(secondary)] == ports
            and [int(port) for port in fields.get("HANDSHAKE_VERIFIED", "").split(",")] == ports
        )
    except (ValueError, TypeError):
        valid_links = False
    if (
        exit_code != 0
        or fields.get("SERVICE_STATUS") != "active"
        or not valid_links
    ):
        raise RuntimeError(
            f"نصب یا فعال‌سازی سرویس کامل نشد (کد خروج {exit_code}).\n"
            + diagnostic_output(output, errors)
        )
    return primary, secondary


REMOTE_SCRIPT = r'''set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive
export TERM="${TERM:-xterm}"
export CREATOR_HOST=__HOST__ CREATOR_SNI=__SNI__ CREATOR_NAME=__NAME__
export CREATOR_SSH_PORT=__SSH_PORT__
export CREATOR_METHOD=__METHOD__
XRAY_BIN=/usr/local/bin/xray
CONFIG_PATH=/usr/local/etc/xray/config.json
CREATOR_STAGE=preflight
CONFIG_REPLACED=0
SERVICE_TOUCHED=0
SERVICE_WAS_ACTIVE=0
BACKUP_PATH=""
CREATOR_TMP=$(mktemp -d)
export CREATOR_TMP XRAY_BIN CONFIG_PATH

stage() { CREATOR_STAGE="$1"; printf 'STAGE=%s\n' "$1"; }
on_error() {
    local code="$1" restore_ok=1
    trap - ERR HUP INT TERM
    printf 'ERROR: Stage %s failed (exit %s).\n' "$CREATOR_STAGE" "$code" >&2
    if [[ "$CREATOR_STAGE" == service || "$CREATOR_STAGE" == verification || "$CREATOR_STAGE" == connection-test ]]; then
        systemctl status xray --no-pager -l >&2 || true
        journalctl -u xray -n 40 --no-pager >&2 || true
    fi
    if [[ "$SERVICE_TOUCHED" == 1 ]]; then
        systemctl stop xray >&2 || true
    fi
    if [[ "$CONFIG_REPLACED" == 1 ]]; then
        if [[ -n "$BACKUP_PATH" ]]; then
            if cp -p -- "$BACKUP_PATH" "$CONFIG_PATH"; then
                printf 'Previous configuration restored.\n' >&2
            else
                restore_ok=0
                printf 'ERROR: Could not restore previous config; backup: %s\n' "$BACKUP_PATH" >&2
            fi
        elif rm -f -- "$CONFIG_PATH"; then
            printf 'Incomplete new configuration removed.\n' >&2
        else
            restore_ok=0
        fi
    fi
    if [[ "$SERVICE_TOUCHED" == 1 && "$SERVICE_WAS_ACTIVE" == 1 && "$restore_ok" == 1 ]]; then
        systemctl reset-failed xray >&2 || true
        if systemctl start xray >&2; then
            printf 'Previous Xray service started again.\n' >&2
        else
            printf 'ERROR: Could not restart previous Xray service; inspect journalctl -u xray.\n' >&2
        fi
    fi
    exit "$code"
}
trap 'on_error $?' ERR
trap 'on_error 129' HUP
trap 'on_error 130' INT
trap 'on_error 143' TERM
trap 'rm -rf -- "$CREATOR_TMP"' EXIT

stage preflight
if [[ "$(id -u)" != 0 ]]; then
    printf 'ERROR: Log in as root to install and configure Xray.\n' >&2
    false
fi
if ! command -v systemctl >/dev/null || [[ ! -d /run/systemd/system ]]; then
    printf 'ERROR: This server needs Linux with systemd (for example Ubuntu/Debian).\n' >&2
    false
fi
if systemctl is-active --quiet xray; then
    SERVICE_WAS_ACTIVE=1
fi
if ! command -v curl >/dev/null || ! command -v python3 >/dev/null; then
    stage dependencies
    if ! command -v apt-get >/dev/null; then
        printf 'ERROR: Install curl and python3 on the server first.\n' >&2
        false
    fi
    apt-get update -qq </dev/null
    apt-get install -y curl ca-certificates python3 unzip </dev/null
fi

stage install
if [[ ! -x "$XRAY_BIN" || ! -f /etc/systemd/system/xray.service ]]; then
    downloaded=0
    for installer_url in \
        https://raw.githubusercontent.com/XTLS/Xray-install/main/install-release.sh \
        https://github.com/XTLS/Xray-install/raw/main/install-release.sh; do
        if curl -fsSL --retry 2 --connect-timeout 15 --max-time 120 \
            "$installer_url" -o "$CREATOR_TMP/install-release.sh" \
            && [[ -s "$CREATOR_TMP/install-release.sh" ]] \
            && bash -n "$CREATOR_TMP/install-release.sh"; then
            downloaded=1
            break
        fi
    done
    if [[ "$downloaded" != 1 ]]; then
        printf 'ERROR: Could not download the official Xray installer from GitHub.\n' >&2
        false
    fi
    bash "$CREATOR_TMP/install-release.sh" install </dev/null
fi
if [[ ! -x "$XRAY_BIN" || ! -f /etc/systemd/system/xray.service ]]; then
    printf 'ERROR: Xray binary or systemd service was not installed.\n' >&2
    false
fi
"$XRAY_BIN" version

stage target-check
python3 - <<'CREATOR_TARGET'
import os

__TARGET_CHECK__

check_reality_target(os.environ['CREATOR_SNI'], require_h2=os.environ['CREATOR_METHOD'] != 'tcp')
CREATOR_TARGET

stage ports
if [[ -f "$CONFIG_PATH" ]]; then
    BACKUP_PATH="${CONFIG_PATH}.backup-$(date +%Y%m%d-%H%M%S)-$$"
    cp -p -- "$CONFIG_PATH" "$BACKUP_PATH"
fi
# Release only this managed service's sockets so reruns can reuse its ports.
SERVICE_TOUCHED=1
systemctl stop xray
python3 - <<'CREATOR_PORTS'
import json
import os
from pathlib import Path

__PORT_SELECTOR__

listen, ports = select_available_ports(
    int(os.environ['CREATOR_SSH_PORT']),
    on_skip=lambda port, reason: print(f'PORT_SKIPPED={port}:{reason}', flush=True),
)
(Path(os.environ['CREATOR_TMP']) / 'ports.json').write_text(
    json.dumps({'listen': listen, 'ports': ports}), encoding='utf-8',
)
print('SELECTED_PORTS=' + ','.join(map(str, ports)), flush=True)
CREATOR_PORTS

stage keys
python3 - <<'CREATOR_PY'
import json
import os
import secrets
import subprocess
import uuid
from pathlib import Path

__KEY_PARSER__

__BUNDLE_BUILDER__

private_key, public_key = parse_x25519_keys(
    subprocess.check_output([os.environ['XRAY_BIN'], 'x25519'], text=True)
)
client_id = str(uuid.uuid4())
short_id = secrets.token_hex(8)
sni = os.environ['CREATOR_SNI']
tmp = Path(os.environ['CREATOR_TMP'])
port_plan = json.loads((tmp / 'ports.json').read_text(encoding='utf-8'))
bundle = build_reality_bundle(
    os.environ['CREATOR_HOST'], sni, os.environ['CREATOR_NAME'],
    port_plan['listen'], port_plan['ports'], private_key, public_key,
    client_id, short_id, method=os.environ['CREATOR_METHOD'],
)
(tmp / 'config.json').write_text(json.dumps(bundle['config'], indent=2), encoding='utf-8')
(tmp / 'links.txt').write_text('\n'.join(bundle['links']) + '\n', encoding='utf-8')
CREATOR_PY

stage config-test
"$XRAY_BIN" run -test -config "$CREATOR_TMP/config.json"
mkdir -p /usr/local/etc/xray
CONFIG_REPLACED=1
install -m 644 "$CREATOR_TMP/config.json" "$CONFIG_PATH"

stage network
modprobe tcp_bbr >/dev/null 2>&1 || true
mkdir -p /etc/sysctl.d
cat > /etc/sysctl.d/99-xray-reality-creator.conf <<'CREATOR_SYSCTL'
net.core.default_qdisc=fq
net.ipv4.tcp_congestion_control=bbr
net.ipv4.tcp_notsent_lowat=16384
net.ipv4.tcp_rmem=4096 87380 67108864
net.ipv4.tcp_wmem=4096 65536 67108864
CREATOR_SYSCTL
if ! sysctl -p /etc/sysctl.d/99-xray-reality-creator.conf; then
    printf 'WARNING: Some network/BBR settings are not supported by this kernel.\n' >&2
fi
creator_ports=$(python3 -c 'import json,os; from pathlib import Path; print(*json.loads((Path(os.environ["CREATOR_TMP"])/"ports.json").read_text())["ports"])')
for creator_port in $creator_ports; do
    if command -v ufw >/dev/null; then
        ufw allow "$creator_port/tcp" || printf 'WARNING: Could not update UFW for port %s.\n' "$creator_port" >&2
    fi
    for creator_firewall in iptables ip6tables; do
        if command -v "$creator_firewall" >/dev/null; then
            if ! "$creator_firewall" -C INPUT -p tcp --dport "$creator_port" -j ACCEPT 2>/dev/null; then
                "$creator_firewall" -I INPUT -p tcp --dport "$creator_port" -j ACCEPT \
                    || printf 'WARNING: Could not update %s for port %s.\n' "$creator_firewall" "$creator_port" >&2
            fi
        fi
    done
done

stage service
systemctl daemon-reload
systemctl enable xray
systemctl reset-failed xray
systemctl restart xray
sleep 2
systemctl is-active --quiet xray
stage verification
CREATOR_XRAY_PID=$(systemctl show xray -p MainPID --value)
export CREATOR_XRAY_PID
python3 - <<'CREATOR_VERIFY'
import json
import os
from pathlib import Path

pid = int(os.environ['CREATOR_XRAY_PID'])
if pid <= 0:
    raise RuntimeError('Xray has no running main process.')
inodes = set()
for fd in (Path('/proc') / str(pid) / 'fd').iterdir():
    try:
        target = os.readlink(fd)
    except FileNotFoundError:
        continue
    if target.startswith('socket:['):
        inodes.add(target[8:-1])
listening = set()
for table in (Path('/proc/net/tcp'), Path('/proc/net/tcp6')):
    if not table.exists():
        continue
    for row in table.read_text().splitlines()[1:]:
        fields = row.split()
        if fields[3] == '0A' and fields[9] in inodes:
            listening.add(int(fields[1].rsplit(':', 1)[1], 16))
ports = json.loads((Path(os.environ['CREATOR_TMP']) / 'ports.json').read_text())['ports']
missing = set(ports) - listening
if missing:
    raise RuntimeError('Xray is not listening on selected TCP ports: ' + ','.join(map(str, sorted(missing))))
print('LISTENERS_VERIFIED=' + ','.join(map(str, ports)))
CREATOR_VERIFY
stage connection-test
python3 - <<'CREATOR_CONNECTION'
import json
import os
from pathlib import Path

__CONNECTION_VERIFIER__

verify_reality_connections(os.environ['XRAY_BIN'], os.environ['CONFIG_PATH'], str(Path(os.environ['CREATOR_TMP']) / 'links.txt'))
ports = json.loads((Path(os.environ['CREATOR_TMP']) / 'ports.json').read_text())['ports']
print('HANDSHAKE_VERIFIED=' + ','.join(map(str, ports)), flush=True)
CREATOR_CONNECTION
printf 'SERVICE_STATUS=active\n'
cat "$CREATOR_TMP/links.txt"
'''
