"""Offline regression checks. Run: python -m unittest -v test_deployment

Linux integration checks use real TCP listeners and isolated command stubs.
They never contact SSH or modify the host's Xray, firewall, or systemd files.
"""

import base64
import errno
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from urllib.parse import parse_qs, unquote, urlsplit

import deployment
from connections import parse_reality_link


def free_ports(count=7):
    held = []
    try:
        for _ in range(count):
            sock = socket.socket()
            sock.bind(("0.0.0.0", 0))
            held.append(sock)
        return [sock.getsockname()[1] for sock in held]
    finally:
        for sock in held:
            sock.close()


def occupy(port, ipv6=False):
    sock = socket.socket(socket.AF_INET6 if ipv6 else socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    if ipv6:
        sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
    sock.bind(("::" if ipv6 else "0.0.0.0", port))
    sock.listen(1)
    return sock


FAKE_SERVER = r'''import json, os, signal, socket, sys, time
from pathlib import Path
root = Path(os.environ['CREATOR_TEST_ROOT'])
config = json.loads((root / 'usr/local/etc/xray/config.json').read_text())
inbounds = config['inbounds']
if os.environ.get('CREATOR_TEST_FAIL') == 'verification' and not config.get('previous'):
    inbounds = inbounds[:1]
sockets = []
for inbound in inbounds:
    address = inbound.get('listen', '0.0.0.0')
    sock = socket.socket(socket.AF_INET6 if ':' in address else socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    if ':' in address:
        sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
    sock.bind((address, inbound['port']))
    sock.listen(1)
    sockets.append(sock)
def finish(*_):
    for sock in sockets:
        sock.close()
    (root / ('closed-' + str(os.getpid()))).write_text('closed')
    sys.exit(0)
signal.signal(signal.SIGTERM, finish)
# This runtime's /proc exposes host PIDs, so mirror the live owner's process
# tables for integration checks instead of reading another PID namespace.
proc = root / 'proc'
fds = proc / str(os.getpid()) / 'fd'
fds.mkdir(parents=True, exist_ok=True)
for sock in sockets:
    (fds / str(sock.fileno())).symlink_to(os.readlink('/proc/self/fd/' + str(sock.fileno())))
(proc / 'net').mkdir(exist_ok=True)
for name in ('tcp', 'tcp6'):
    table = Path('/proc/self/net') / name
    if table.exists():
        (proc / 'net' / name).write_text(table.read_text())
(root / 'ready').write_text('ready')
while True:
    time.sleep(0.1)
'''


FAKE_COMMAND = r'''#!/usr/bin/env python3
import base64, json, os, signal, subprocess, sys, time
from pathlib import Path
root = Path(os.environ['CREATOR_TEST_ROOT'])
name = Path(sys.argv[0]).name
args = sys.argv[1:]
with (root / 'commands.jsonl').open('a') as out:
    out.write(json.dumps([name, *args]) + '\n')
state = root / 'state.json'
config_path = root / 'usr/local/etc/xray/config.json'
def pid():
    return json.loads(state.read_text()).get('pid', 0) if state.exists() else 0
def config():
    return json.loads(config_path.read_text()) if config_path.exists() else {}
def stop():
    old = pid()
    if old:
        try:
            os.kill(old, signal.SIGTERM)
        except ProcessLookupError:
            pass
        for _ in range(100):
            if (root / ('closed-' + str(old))).exists():
                break
            time.sleep(0.01)
    state.write_text(json.dumps({'pid': 0}))
def start():
    failure = os.environ.get('CREATOR_TEST_FAIL')
    if failure == 'service' and not config().get('previous'):
        print('Simulated service startup failure', file=sys.stderr)
        return 1
    ready = root / 'ready'
    ready.unlink(missing_ok=True)
    process = subprocess.Popen([sys.executable, str(root / 'server.py')],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               start_new_session=True)
    state.write_text(json.dumps({'pid': process.pid}))
    for _ in range(200):
        if process.poll() is not None:
            state.write_text(json.dumps({'pid': 0}))
            return 1
        if ready.exists():
            return 0
        time.sleep(0.01)
    stop()
    return 1
if name == 'id':
    print('1000' if os.environ.get('CREATOR_TEST_FAIL') == 'nonroot' else '0')
elif name == 'systemctl':
    action = args[0]
    if action == 'is-active':
        active = bool(pid())
        if os.environ.get('CREATOR_TEST_FAIL') == 'inactive' and not config().get('previous'):
            active = False
        sys.exit(0 if active else 3)
    if action == 'stop':
        stop()
    elif action in ('start', 'restart'):
        stop()
        sys.exit(start())
    elif action == 'show':
        print(pid())
elif name == 'xray':
    if args == ['x25519']:
        if os.environ.get('CREATOR_TEST_FAIL') == 'keys':
            print('Invalid key output')
        else:
            print('PrivateKey: ' + base64.urlsafe_b64encode(bytes([17])*32).decode().rstrip('='))
            print('Password: ' + base64.urlsafe_b64encode(bytes([34])*32).decode().rstrip('='))
            print('Hash32: this-is-not-the-public-key')
    elif args and args[0] == 'version':
        print('Offline test Xray')
    elif '-test' in args:
        json.loads(Path(args[args.index('-config')+1]).read_text())
        if os.environ.get('CREATOR_TEST_FAIL') == 'config-test':
            print('Simulated invalid configuration', file=sys.stderr)
            sys.exit(42)
        print('Configuration OK.')
elif name == 'curl':
    print('Simulated download failure', file=sys.stderr)
    sys.exit(22)
elif name in ('iptables', 'ip6tables') and '-C' in args:
    sys.exit(1)
sys.exit(0)
'''


class Sandbox:
    def __init__(self, active=False, failure="", existing_config=True):
        self.temp = tempfile.TemporaryDirectory(prefix="xray-regression-")
        self.root = Path(self.temp.name)
        self.ports = free_ports()
        self.env = {**os.environ, 'CREATOR_TEST_ROOT': str(self.root),
                    'CREATOR_TEST_FAIL': failure,
                    'PATH': str(self.root / 'bin') + os.pathsep + os.environ['PATH']}
        for directory in ('bin', 'usr/local/bin', 'usr/local/etc/xray',
                          'etc/systemd/system', 'run/systemd/system', 'etc/sysctl.d'):
            (self.root / directory).mkdir(parents=True, exist_ok=True)
        command = self.root / 'command.py'
        command.write_text(FAKE_COMMAND)
        command.chmod(0o755)
        for name in ('id', 'systemctl', 'journalctl', 'sysctl', 'modprobe', 'ufw',
                     'iptables', 'ip6tables', 'sleep', 'curl'):
            (self.root / 'bin' / name).symlink_to(command)
        (self.root / 'usr/local/bin/xray').symlink_to(command)
        (self.root / 'etc/systemd/system/xray.service').write_text('test unit')
        (self.root / 'server.py').write_text(FAKE_SERVER)
        self.config_path = self.root / 'usr/local/etc/xray/config.json'
        self.original = json.dumps({'previous': True, 'inbounds': [
            {'port': self.ports[0]}, {'port': self.ports[1]},
        ]}).encode()
        if existing_config:
            self.config_path.write_bytes(self.original)
        if active:
            self.command('systemctl', 'start', 'xray')

    def command(self, name, *args):
        return subprocess.run([str(self.root / 'bin' / name), *args],
                              env=self.env, capture_output=True, text=True, check=True)

    def run(self, ssh_port=22, method='tcp'):
        script = deployment.build_deployment_script('192.0.2.10', 'www.example.com', "نام ' $()", ssh_port,
                                                    method=method)
        # Use unprivileged isolated ports for all seven production candidate slots.
        script = script.replace('candidates=(443, 2053, 2083, 8443, 9443, 10443, 11443)',
                                'candidates=' + repr(tuple(self.ports)))
        # Stub only the live network checks. Keep the production helper definitions
        # and all actual port/config/service/listener/rollback commands in this test.
        target_call = (
            "check_reality_target(os.environ['CREATOR_SNI'], "
            "require_h2=os.environ['CREATOR_METHOD'] != 'tcp')"
        )
        connection_call = (
            "verify_reality_connections(os.environ['XRAY_BIN'], os.environ['CONFIG_PATH'], "
            "str(Path(os.environ['CREATOR_TMP']) / 'links.txt'))"
        )
        for call in (target_call, connection_call):
            if script.count(call) != 1:
                raise AssertionError('Expected exactly one isolated network helper call: ' + call)
        script = script.replace(target_call, (
            "if os.environ.get('CREATOR_TEST_FAIL') == 'target-check':\n"
            "    raise RuntimeError('Simulated REALITY target failure')\n"
            "print('TARGET_VERIFIED=' + os.environ['CREATOR_SNI'])"
        ))
        script = script.replace(connection_call, (
            "if os.environ.get('CREATOR_TEST_FAIL') == 'connection-test':\n"
            "    raise RuntimeError('Simulated REALITY handshake failure')\n"
            "for port in json.loads((Path(os.environ['CREATOR_TMP']) / 'ports.json').read_text())['ports']:\n"
            "    print('REALITY_PORT_VERIFIED=' + str(port))"
        ))
        for prefix in ('/usr/local/bin', '/usr/local/etc/xray', '/etc/systemd/system',
                       '/run/systemd/system', '/etc/sysctl.d'):
            script = script.replace(prefix, str(self.root) + prefix)
        script = script.replace('CREATOR_TMP=$(mktemp -d)',
                                f'CREATOR_TMP=$(mktemp -d "{self.root}/runtime.XXXXXX")')
        for path in ('/proc', '/proc/net/tcp', '/proc/net/tcp6'):
            script = script.replace(f"Path('{path}')", f"Path('{self.root}{path}')")
        syntax = subprocess.run(['bash', '-n'], input=script, text=True, capture_output=True)
        if syntax.returncode:
            raise AssertionError(syntax.stderr)
        return subprocess.run(['bash', '-s'], input=script, env=self.env,
                              text=True, capture_output=True, timeout=20)

    @property
    def pid(self):
        state = self.root / 'state.json'
        return json.loads(state.read_text()).get('pid', 0) if state.exists() else 0

    @property
    def commands(self):
        return [json.loads(line) for line in (self.root / 'commands.jsonl').read_text().splitlines()]

    def close(self):
        try:
            self.command('systemctl', 'stop', 'xray')
        finally:
            self.temp.cleanup()


class DeploymentTests(unittest.TestCase):
    def bundle(self, **changes):
        arguments = {
            'host': '192.0.2.10', 'sni': 'www.example.com', 'name': 'Test',
            'listen': '::', 'ports': [443, 2053],
            'private_key': base64.urlsafe_b64encode(bytes([17]) * 32).decode().rstrip('='),
            'public_key': base64.urlsafe_b64encode(bytes([34]) * 32).decode().rstrip('='),
            'client_id': '11111111-2222-4333-8444-555555555555',
            'short_id': '0011223344556677',
        }
        arguments.update(changes)
        return deployment.build_reality_bundle(**arguments), arguments

    def assert_bundle_matches_links(self, bundle, arguments, transports):
        self.assertEqual(set(bundle), {'config', 'links'})
        self.assertEqual(len(bundle['links']), 3)
        self.assertEqual(bundle['links'][0], 'PORTS=' + ','.join(map(str, arguments['ports'])))
        inbounds = bundle['config']['inbounds']
        self.assertEqual(len(inbounds), 2)
        for role, transport, port, inbound, metadata in zip(
                ('PRIMARY', 'SECONDARY'), transports, arguments['ports'], inbounds, bundle['links'][1:]):
            self.assertTrue(metadata.startswith('LINK_' + role + '='))
            raw_link = metadata.partition('=')[2]
            link = parse_reality_link(raw_link)
            stream = inbound['streamSettings']
            reality = stream['realitySettings']
            client, = inbound['settings']['clients']
            self.assertEqual(inbound['port'], port)
            self.assertEqual(inbound['listen'], arguments['listen'])
            self.assertEqual(inbound['protocol'], 'vless')
            self.assertEqual(inbound['settings']['decryption'], 'none')
            self.assertEqual(link['port'], port)
            self.assertEqual(link['host'], arguments['host'].strip('[]'))
            self.assertEqual(stream['network'], transport)
            self.assertEqual(stream['security'], 'reality')
            self.assertEqual(link['transport'], transport)
            self.assertEqual(client['id'], arguments['client_id'])
            self.assertEqual(link['id'], arguments['client_id'])
            self.assertEqual(reality['privateKey'], arguments['private_key'])
            self.assertEqual(link['public_key'], arguments['public_key'])
            self.assertNotIn(arguments['private_key'], raw_link)
            self.assertEqual(reality['serverNames'], [arguments['sni']])
            self.assertEqual(link['sni'], arguments['sni'])
            self.assertEqual(reality['shortIds'], [arguments['short_id']])
            self.assertEqual(link['short_id'], arguments['short_id'])
            self.assertTrue(unquote(urlsplit(raw_link).fragment).startswith(arguments['name']))
            if transport == 'tcp':
                self.assertEqual(client['flow'], 'xtls-rprx-vision')
                self.assertEqual(link['flow'], 'xtls-rprx-vision')
                self.assertNotIn('xhttpSettings', stream)
            else:
                self.assertNotIn('flow', client)
                self.assertEqual(link['flow'], '')
                self.assertEqual(stream['xhttpSettings']['mode'], 'auto')
                self.assertEqual(link['mode'], 'auto')
                self.assertEqual(stream['xhttpSettings']['path'], link['path'])
                self.assertTrue(link['path'].startswith('/'))
                self.assertNotIn('flow', parse_qs(urlsplit(raw_link).query))

    def test_reality_bundle_default_preserves_two_tcp_vision_links(self):
        bundle, arguments = self.bundle()
        self.assert_bundle_matches_links(bundle, arguments, ('tcp', 'tcp'))

    def test_reality_bundle_all_methods_match_links_credentials_and_ipv6(self):
        for method, transports in [('tcp', ('tcp', 'tcp')), ('mixed', ('tcp', 'xhttp')),
                                   ('xhttp', ('xhttp', 'xhttp'))]:
            for host in ('2001:db8::1', '[2001:db8::1]'):
                with self.subTest(method=method, host=host):
                    bundle, arguments = self.bundle(host=host, method=method,
                                                    name="نام ' $() ?&#%+",
                                                    xhttp_path='/مسیر&a%+/')
                    self.assert_bundle_matches_links(bundle, arguments, transports)
                    for line, transport in zip(bundle['links'][1:], transports):
                        raw_link = line.partition('=')[2]
                        self.assertIn('@[2001:db8::1]:', raw_link)
                        if transport == 'xhttp':
                            self.assertEqual(parse_reality_link(raw_link)['path'], arguments['xhttp_path'])

    def test_reality_bundle_xhttp_default_paths_are_random_and_shared_by_links(self):
        first, arguments = self.bundle(method='xhttp')
        second, _ = self.bundle(method='xhttp')
        self.assert_bundle_matches_links(first, arguments, ('xhttp', 'xhttp'))
        first_paths = [inbound['streamSettings']['xhttpSettings']['path']
                       for inbound in first['config']['inbounds']]
        second_paths = [inbound['streamSettings']['xhttpSettings']['path']
                        for inbound in second['config']['inbounds']]
        self.assertNotEqual(first_paths, second_paths)

    def test_reality_bundle_rejects_invalid_method_ports_and_paths(self):
        invalid = [{'method': 'ws'}, {'method': 'TCP'}, {'ports': [443, 443]},
                   {'ports': [443]}, {'ports': [443, 2053, 8443]},
                   {'ports': [0, 2053]}, {'ports': [443, 65536]},
                   {'method': 'xhttp', 'xhttp_path': 'relative'},
                   {'method': 'xhttp', 'xhttp_path': '/bad\r\npath'},
                   {'method': 'xhttp', 'xhttp_path': '/bad\0path'},
                   {'method': 'xhttp', 'xhttp_path': '/bad\tpath'},
                   {'method': 'xhttp', 'xhttp_path': '/bad path'},
                   {'method': 'xhttp', 'xhttp_path': '/bad?query'},
                   {'method': 'xhttp', 'xhttp_path': '/bad#fragment'}]
        for changes in invalid:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                self.bundle(**changes)

    def test_key_formats_and_hash_ignored(self):
        private = base64.urlsafe_b64encode(bytes([17])*32).decode().rstrip('=')
        public = base64.urlsafe_b64encode(bytes([34])*32).decode().rstrip('=')
        for labels in [('Private key', 'Public key'), ('PrivateKey', 'PublicKey'),
                       ('PrivateKey', 'Password'), ('PrivateKey', 'Password (PublicKey)')]:
            with self.subTest(labels=labels):
                self.assertEqual(deployment.parse_x25519_keys(
                    f'{labels[0]}: {private}\n{labels[1]}: {public}\nHash32: invalid\n'),
                    (private, public))
        with self.assertRaises(ValueError):
            deployment.parse_x25519_keys(f'PrivateKey: {private}\nHash32: {public}')

    def test_real_busy_port_is_skipped(self):
        ports = free_ports(4)
        blocker = occupy(ports[1])
        self.addCleanup(blocker.close)
        skips = []
        _, selected = deployment.select_available_ports(22, ports, lambda *args: skips.append(args))
        self.assertEqual(selected, [ports[0], ports[2]])
        self.assertIn((ports[1], 'busy'), skips)
        self.assertEqual(blocker.getsockname()[1], ports[1])

    @unittest.skipUnless(socket.has_ipv6, 'No IPv6')
    def test_ipv6_listener_conflict_is_skipped(self):
        ports = free_ports(4)
        try:
            blocker = occupy(ports[1], ipv6=True)
        except OSError as exc:
            self.skipTest(str(exc))
        self.addCleanup(blocker.close)
        _, selected = deployment.select_available_ports(22, ports)
        self.assertEqual(selected, [ports[0], ports[2]])

    def test_ssh_port_never_selected(self):
        ports = free_ports(4)
        _, selected = deployment.select_available_ports(ports[0], ports)
        self.assertEqual(selected, ports[1:3])

    def test_insufficient_ports_release_all_probes(self):
        ports = free_ports(2)
        with self.assertRaisesRegex(RuntimeError, 'No two free TCP ports'):
            deployment.select_available_ports(ports[1], ports)
        sock = occupy(ports[0])
        sock.close()

    def test_permission_denied_can_use_another_port(self):
        class Probe:
            def setsockopt(self, *args): pass
            def bind(self, address):
                if address[1] == 443:
                    raise PermissionError(errno.EACCES, 'denied')
            def listen(self, backlog): pass
            def close(self): pass
        with mock.patch('socket.has_ipv6', False), mock.patch('socket.socket', side_effect=lambda *args: Probe()):
            skips = []
            _, ports = deployment.select_available_ports(22, on_skip=lambda *args: skips.append(args))
        self.assertEqual(ports, [2053, 2083])
        self.assertIn((443, 'permission'), skips)

    def test_parse_selected_ports_and_reject_false_success(self):
        a, b = 'vless://user@192.0.2.10:2053?security=reality', 'vless://user@192.0.2.10:2083?security=reality'
        output = f'SERVICE_STATUS=active\nHANDSHAKE_VERIFIED=2053,2083\nPORTS=2053,2083\nLINK_PRIMARY={a}\nLINK_SECONDARY={b}\n'
        self.assertEqual(deployment.parse_deployment_result(0, output), (a, b))
        for code, text in [(1, output), (0, output.replace('active', 'failed')),
                           (0, output.replace('PORTS=2053,2083', 'PORTS=2053,443')),
                           (0, output.replace(b, a)), (0, output.replace('LINK_SECONDARY=', 'MISSING=')),
                           (0, output.replace('HANDSHAKE_VERIFIED=2053,2083\n', '')),
                           (0, output.replace('HANDSHAKE_VERIFIED=2053,2083', 'HANDSHAKE_VERIFIED=2053,443')),
                           (0, output.replace('HANDSHAKE_VERIFIED=2053,2083', 'HANDSHAKE_VERIFIED=2083,2053')),
                           (0, output.replace('HANDSHAKE_VERIFIED=2053,2083', 'HANDSHAKE_VERIFIED='))]:
            with self.subTest(code=code, text=text):
                with self.assertRaises(RuntimeError):
                    deployment.parse_deployment_result(code, text)
        legacy = f'SERVICE_STATUS=active\nLINK_2053={a}\nLINK_443={b.replace(":2083", ":443")}\n'
        with self.assertRaises(RuntimeError):
            deployment.parse_deployment_result(0, legacy)
        legacy_verified = 'HANDSHAKE_VERIFIED=2053,443\n' + legacy
        self.assertEqual(deployment.connection_port(deployment.parse_deployment_result(0, legacy_verified)[1]), 443)

    def test_ipv6_link_port(self):
        self.assertEqual(deployment.connection_port('vless://user@[2001:db8::1]:8443'), 8443)

    def test_input_and_script_syntax(self):
        for host in ['192.0.2.10', '2001:db8::1', 'server.example.com']:
            for method in ('tcp', 'mixed', 'xhttp'):
                with self.subTest(host=host, method=method):
                    script = deployment.build_deployment_script(host, 'www.example.com', "نام ' $()", 22,
                                                                method=method)
                    self.assertNotIn('__PORT_SELECTOR__', script)
                    self.assertNotIn('__TARGET_CHECK__', script)
                    self.assertNotIn('__CONNECTION_VERIFIER__', script)
                    result = subprocess.run(['bash', '-n'], input=script, text=True, capture_output=True)
                    self.assertEqual(result.returncode, 0, result.stderr)
        for bad in ['https://example.com', 'example.com; touch file', 'a/../../b']:
            with self.assertRaises(ValueError):
                deployment.build_deployment_script(bad, 'example.com', 'test')
        for method in ('ws', 'TCP', '', None):
            with self.subTest(method=method), self.assertRaises(ValueError):
                deployment.build_deployment_script('192.0.2.10', 'example.com', 'test', method=method)

    def test_error_popup_is_concise_and_diagnostics_hide_links(self):
        details = 'failed\n' + 'log line\n'*200 + 'bind: address already in use'
        self.assertIn('پورت', deployment.deployment_error_summary(details))
        self.assertLess(len(deployment.deployment_error_summary(details)), 700)
        self.assertNotIn('vless://', deployment.diagnostic_output('LINK_PRIMARY=vless://secret\nOK', ''))


@unittest.skipUnless(sys.platform.startswith('linux') and shutil.which('bash'), 'Linux integration')
class IntegrationTests(unittest.TestCase):
    def sandbox(self, **kwargs):
        sandbox = Sandbox(**kwargs)
        self.addCleanup(sandbox.close)
        return sandbox

    def assert_success(self, sandbox, result, expected, transports=('tcp', 'tcp')):
        self.assertEqual(result.returncode, 0, result.stderr)
        primary, secondary = deployment.parse_deployment_result(result.returncode, result.stdout, result.stderr)
        self.assertEqual([deployment.connection_port(primary), deployment.connection_port(secondary)], expected)
        config = json.loads(sandbox.config_path.read_text())
        self.assertEqual([i['port'] for i in config['inbounds']], expected)
        for inbound, raw_link, transport in zip(config['inbounds'], (primary, secondary), transports):
            fields = parse_reality_link(raw_link)
            stream = inbound['streamSettings']
            client, = inbound['settings']['clients']
            self.assertEqual(stream['network'], transport)
            self.assertEqual(fields['transport'], transport)
            self.assertEqual(client['id'], fields['id'])
            self.assertEqual(stream['realitySettings']['serverNames'], [fields['sni']])
            self.assertEqual(stream['realitySettings']['shortIds'], [fields['short_id']])
            self.assertTrue(unquote(urlsplit(raw_link).fragment).startswith("نام ' $()"))
            if transport == 'xhttp':
                self.assertNotIn('flow', client)
                self.assertEqual(fields['flow'], '')
                self.assertEqual(stream['xhttpSettings']['mode'], fields['mode'])
                self.assertEqual(stream['xhttpSettings']['path'], fields['path'])
            else:
                self.assertEqual(client['flow'], fields['flow'])
        self.assertIn('LISTENERS_VERIFIED=', result.stdout)
        self.assertIn('HANDSHAKE_VERIFIED=' + ','.join(map(str, expected)), result.stdout)
        allowed = [command[2] for command in sandbox.commands if command[:2] == ['ufw', 'allow']]
        self.assertEqual(allowed, [f'{port}/tcp' for port in expected])
        for firewall in ('iptables', 'ip6tables'):
            allowed_ports = [command[command.index('--dport') + 1] for command in sandbox.commands
                             if command[:2] == [firewall, '-I']]
            self.assertEqual(allowed_ports, list(map(str, expected)))
        for command in sandbox.commands:
            if command[0] == 'systemctl' and command[1] in ('stop', 'start', 'restart'):
                self.assertEqual(command[2], 'xray')

    def test_occupied_secondary_port_stays_running_and_links_use_fallback(self):
        sandbox = self.sandbox()
        blocker = occupy(sandbox.ports[1])
        self.addCleanup(blocker.close)
        result = sandbox.run()
        self.assert_success(sandbox, result, [sandbox.ports[0], sandbox.ports[2]])
        self.assertIn(f'PORT_SKIPPED={sandbox.ports[1]}:busy', result.stdout)
        self.assertEqual(blocker.getsockname()[1], sandbox.ports[1])
        backups = list(sandbox.config_path.parent.glob('config.json.backup-*'))
        self.assertEqual(backups[0].read_bytes(), sandbox.original)
        commands = sandbox.commands
        self.assertLess(commands.index(['systemctl', 'reset-failed', 'xray']), commands.index(['systemctl', 'restart', 'xray']))

    def test_active_xray_can_reuse_its_own_ports(self):
        sandbox = self.sandbox(active=True)
        result = sandbox.run()
        self.assert_success(sandbox, result, sandbox.ports[:2])

    def test_mixed_and_xhttp_generate_matching_config_links_and_firewall_ports(self):
        for method, transports in [('mixed', ('tcp', 'xhttp')), ('xhttp', ('xhttp', 'xhttp'))]:
            with self.subTest(method=method):
                sandbox = self.sandbox(active=True)
                result = sandbox.run(method=method)
                self.assert_success(sandbox, result, sandbox.ports[:2], transports)

    def test_new_methods_use_fallback_ports_when_ssh_or_listener_occupies_candidates(self):
        for method, transports in [('mixed', ('tcp', 'xhttp')), ('xhttp', ('xhttp', 'xhttp'))]:
            with self.subTest(method=method):
                sandbox = self.sandbox()
                blocker = occupy(sandbox.ports[1])
                self.addCleanup(blocker.close)
                result = sandbox.run(ssh_port=sandbox.ports[0], method=method)
                self.assert_success(sandbox, result, sandbox.ports[2:4], transports)
                self.assertIn(f'PORT_SKIPPED={sandbox.ports[0]}:SSH', result.stdout)
                self.assertIn(f'PORT_SKIPPED={sandbox.ports[1]}:busy', result.stdout)

    def test_ssh_candidate_is_skipped_in_config_firewall_and_links(self):
        sandbox = self.sandbox()
        result = sandbox.run(ssh_port=sandbox.ports[0])
        self.assert_success(sandbox, result, sandbox.ports[1:3])

    def test_both_preferred_ports_occupied(self):
        sandbox = self.sandbox()
        blockers = [occupy(port) for port in sandbox.ports[:2]]
        for blocker in blockers:
            self.addCleanup(blocker.close)
        result = sandbox.run()
        self.assert_success(sandbox, result, sandbox.ports[2:4])

    def test_failures_restore_config_and_previously_running_service(self):
        for failure in ('keys', 'config-test', 'service', 'inactive', 'verification', 'connection-test'):
            with self.subTest(failure=failure):
                sandbox = Sandbox(active=True, failure=failure)
                try:
                    result = sandbox.run()
                    self.assertNotEqual(result.returncode, 0, result.stdout)
                    self.assertEqual(sandbox.config_path.read_bytes(), sandbox.original)
                    self.assertTrue(sandbox.pid)
                    self.assertNotIn('SERVICE_STATUS=active', result.stdout)
                    self.assertNotIn('LINK_PRIMARY=', result.stdout)
                    self.assertNotIn('HANDSHAKE_VERIFIED=', result.stdout)
                    self.assertIn('Previous Xray service started again.', result.stderr)
                finally:
                    sandbox.close()

    def test_mixed_and_xhttp_connection_failures_restore_previous_running_configuration(self):
        for method in ('mixed', 'xhttp'):
            with self.subTest(method=method):
                sandbox = Sandbox(active=True, failure='connection-test')
                try:
                    result = sandbox.run(method=method)
                    self.assertNotEqual(result.returncode, 0, result.stdout)
                    self.assertEqual(sandbox.config_path.read_bytes(), sandbox.original)
                    self.assertTrue(sandbox.pid)
                    self.assertNotIn('SERVICE_STATUS=active', result.stdout)
                    self.assertNotIn('LINK_PRIMARY=', result.stdout)
                    self.assertNotIn('HANDSHAKE_VERIFIED=', result.stdout)
                    self.assertIn('Previous Xray service started again.', result.stderr)
                    for firewall in ('iptables', 'ip6tables'):
                        allowed_ports = [command[command.index('--dport') + 1]
                                         for command in sandbox.commands
                                         if command[:2] == [firewall, '-I']]
                        self.assertEqual(allowed_ports, list(map(str, sandbox.ports[:2])))
                finally:
                    sandbox.close()

    def test_no_free_ports_does_not_overwrite_old_configuration(self):
        sandbox = self.sandbox()
        blockers = [occupy(port) for port in sandbox.ports]
        for blocker in blockers:
            self.addCleanup(blocker.close)
        result = sandbox.run()
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(sandbox.config_path.read_bytes(), sandbox.original)
        self.assertEqual(sandbox.pid, 0)
        self.assertNotIn('LINK_PRIMARY=', result.stdout)
        self.assertIn('No two free TCP ports', result.stderr)

    def test_first_failed_deployment_removes_incomplete_config(self):
        sandbox = self.sandbox(failure='service', existing_config=False)
        result = sandbox.run()
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(sandbox.config_path.exists())
        self.assertEqual(sandbox.pid, 0)

    def test_installer_download_failure_does_not_stop_running_service(self):
        sandbox = self.sandbox(active=True)
        original_pid = sandbox.pid
        (sandbox.root / 'usr/local/bin/xray').unlink()
        result = sandbox.run()
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(sandbox.pid, original_pid)
        self.assertEqual(sandbox.config_path.read_bytes(), sandbox.original)
        self.assertIn('Could not download', result.stderr)
        self.assertNotIn(['systemctl', 'stop', 'xray'], sandbox.commands)

    def test_target_check_failure_preserves_running_service_and_configuration(self):
        sandbox = self.sandbox(active=True, failure='target-check')
        original_pid = sandbox.pid
        result = sandbox.run()
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(sandbox.pid, original_pid)
        self.assertEqual(sandbox.config_path.read_bytes(), sandbox.original)
        self.assertIn('Simulated REALITY target failure', result.stderr)
        self.assertNotIn(['systemctl', 'stop', 'xray'], sandbox.commands)
        self.assertFalse(list(sandbox.config_path.parent.glob('config.json.backup-*')))
        self.assertNotIn('SERVICE_STATUS=active', result.stdout)
        self.assertNotIn('LINK_PRIMARY=', result.stdout)

    def test_nonroot_failure_does_not_touch_running_service(self):
        sandbox = self.sandbox(active=True, failure='nonroot')
        original_pid = sandbox.pid
        result = sandbox.run()
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(sandbox.pid, original_pid)
        self.assertEqual(sandbox.config_path.read_bytes(), sandbox.original)
        self.assertIn('Log in as root', result.stderr)
        self.assertNotIn(['systemctl', 'stop', 'xray'], sandbox.commands)
        self.assertNotIn('LINK_PRIMARY=', result.stdout)


if __name__ == '__main__':
    unittest.main()
