import os
import sys
import json
import time
import threading
import io
import queue
import tkinter as tk
from tkinter import messagebox, filedialog
import customtkinter as ctk
import paramiko
import pyperclip
from PIL import Image
import qrcode
from connections import parse_reality_link, probe_public_links
from deployment import (
    build_deployment_script, connection_port, deployment_error_summary,
    normalize_host, parse_deployment_result, run_remote_script,
)

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

HISTORY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "servers_history.json")
CONNECTION_METHODS = {
    "TCP + XHTTP": "mixed",
    "XHTTP + REALITY": "xhttp",
    "TCP + REALITY (V2BOX)": "tcp",
}

class XRayCreatorApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("⚡ VLESS-REALITY Auto Creator v1.3 - TCP / XHTTP")
        self.geometry("900x750")
        self.minsize(850, 700)

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.is_running = False
        self.ui_queue = queue.Queue()

        self.create_widgets()
        self.load_history()
        self.after(75, self.process_ui_queue)

    def create_widgets(self):
        self.tabview = ctk.CTkTabview(self, corner_radius=12)
        self.tabview.grid(row=0, column=0, padx=15, pady=15, sticky="nsew")

        creator_tab = self.tabview.add("🚀 ساخت لینک جدید (1-Click Deploy)")
        self.tab_creator = ctk.CTkScrollableFrame(creator_tab, fg_color="transparent")
        self.tab_creator.pack(fill="both", expand=True)
        self.tab_history = self.tabview.add("📜 تاریخچه سرورها (History)")

        self.setup_creator_tab()
        self.setup_history_tab()

    def setup_creator_tab(self):
        tab = self.tab_creator
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_columnconfigure(1, weight=1)
        tab.grid_rowconfigure(5, weight=1)

        title_frame = ctk.CTkFrame(tab, fg_color="transparent")
        title_frame.grid(row=0, column=0, columnspan=2, pady=(5, 10), sticky="ew")

        lbl_title = ctk.CTkLabel(
            title_frame, 
            text="⚡ ساخت VLESS-REALITY با روش‌های TCP و XHTTP",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        lbl_title.pack(anchor="center")

        lbl_subtitle = ctk.CTkLabel(
            title_frame,
            text="بهینه‌سازی شبکه جهت جلوگیری از نوسان پینگ و افت سرعت در ساعات شلوغی",
            font=ctk.CTkFont(size=12),
            text_color="gray"
        )
        lbl_subtitle.pack(anchor="center", pady=(2, 0))

        input_frame = ctk.CTkFrame(tab, corner_radius=10)
        input_frame.grid(row=1, column=0, columnspan=2, padx=10, pady=5, sticky="nsew")
        input_frame.grid_columnconfigure(0, weight=1)
        input_frame.grid_columnconfigure(1, weight=1)

        lbl_ip = ctk.CTkLabel(input_frame, text="آدرس آی‌پی سرور (Server IP):", anchor="e", font=ctk.CTkFont(size=12, weight="bold"))
        lbl_ip.grid(row=0, column=0, padx=15, pady=(10, 2), sticky="w")
        self.entry_ip = ctk.CTkEntry(input_frame, placeholder_text="مثال: 65.109.213.97", height=35)
        self.entry_ip.grid(row=1, column=0, padx=15, pady=(0, 10), sticky="ew")

        lbl_port = ctk.CTkLabel(input_frame, text="پورت SSH (SSH Port):", anchor="e", font=ctk.CTkFont(size=12, weight="bold"))
        lbl_port.grid(row=0, column=1, padx=15, pady=(10, 2), sticky="w")
        self.entry_port = ctk.CTkEntry(input_frame, placeholder_text="22", height=35)
        self.entry_port.insert(0, "22")
        self.entry_port.grid(row=1, column=1, padx=15, pady=(0, 10), sticky="ew")

        lbl_user = ctk.CTkLabel(input_frame, text="نام کاربری (Username):", anchor="e", font=ctk.CTkFont(size=12, weight="bold"))
        lbl_user.grid(row=2, column=0, padx=15, pady=(5, 2), sticky="w")
        self.entry_user = ctk.CTkEntry(input_frame, placeholder_text="root", height=35)
        self.entry_user.insert(0, "root")
        self.entry_user.grid(row=3, column=0, padx=15, pady=(0, 10), sticky="ew")

        lbl_pass = ctk.CTkLabel(input_frame, text="رمز عبور سرور (Password):", anchor="e", font=ctk.CTkFont(size=12, weight="bold"))
        lbl_pass.grid(row=2, column=1, padx=15, pady=(5, 2), sticky="w")
        
        pass_subframe = ctk.CTkFrame(input_frame, fg_color="transparent")
        pass_subframe.grid(row=3, column=1, padx=15, pady=(0, 10), sticky="ew")
        pass_subframe.grid_columnconfigure(0, weight=1)

        self.entry_pass = ctk.CTkEntry(pass_subframe, placeholder_text="رمز عبور SSH سرور", show="*", height=35)
        self.entry_pass.grid(row=0, column=0, sticky="ew", padx=(0, 5))

        self.btn_show_pass = ctk.CTkButton(pass_subframe, text="👁", width=35, height=35, command=self.toggle_password)
        self.btn_show_pass.grid(row=0, column=1)

        lbl_sni = ctk.CTkLabel(input_frame, text="دامنه استتار (SNI Target):", anchor="e", font=ctk.CTkFont(size=12, weight="bold"))
        lbl_sni.grid(row=4, column=0, padx=15, pady=(5, 2), sticky="w")
        self.combo_sni = ctk.CTkComboBox(
            input_frame, 
            values=["www.speedtest.net", "speedtest.net", "www.microsoft.com", "www.yahoo.com", "cloudflare.com", "gateway.icloud.com"],
            height=35
        )
        self.combo_sni.set("www.speedtest.net")
        self.combo_sni.grid(row=5, column=0, padx=15, pady=(0, 15), sticky="ew")

        lbl_name = ctk.CTkLabel(input_frame, text="نام دلخواه سرور (Config Name):", anchor="e", font=ctk.CTkFont(size=12, weight="bold"))
        lbl_name.grid(row=4, column=1, padx=15, pady=(5, 2), sticky="w")
        self.entry_name = ctk.CTkEntry(input_frame, placeholder_text="مثال: My-Server-1", height=35)
        self.entry_name.insert(0, "HighSpeed-Reality")
        self.entry_name.grid(row=5, column=1, padx=15, pady=(0, 15), sticky="ew")

        ctk.CTkLabel(input_frame, text="روش اتصال (Transport):", anchor="e",
                     font=ctk.CTkFont(size=12, weight="bold")).grid(
            row=6, column=0, columnspan=2, padx=15, pady=(5, 2), sticky="w")
        self.combo_method = ctk.CTkComboBox(input_frame, values=list(CONNECTION_METHODS),
                                          height=35, command=self.update_method_hint)
        self.combo_method.set("TCP + XHTTP")
        self.combo_method.grid(row=7, column=0, columnspan=2, padx=15, pady=(0, 5), sticky="ew")
        self.lbl_method_hint = ctk.CTkLabel(input_frame, text="", wraplength=750, justify="right",
                                           font=ctk.CTkFont(size=12), text_color="#e9c46a")
        self.lbl_method_hint.grid(row=8, column=0, columnspan=2, padx=15, pady=(0, 12), sticky="ew")
        self.update_method_hint("TCP + XHTTP")

        self.btn_start = ctk.CTkButton(
            tab,
            text="🚀 نصب و بررسی اتصال (1-Click Start)",
            font=ctk.CTkFont(size=16, weight="bold"),
            height=45,
            fg_color="#1f6aa5",
            hover_color="#144d75",
            command=self.start_deployment_thread
        )
        self.btn_start.grid(row=2, column=0, columnspan=2, padx=10, pady=(10, 5), sticky="ew")

        self.prog_bar = ctk.CTkProgressBar(tab, height=12)
        self.prog_bar.grid(row=3, column=0, columnspan=2, padx=10, pady=(5, 2), sticky="ew")
        self.prog_bar.set(0)

        self.lbl_status = ctk.CTkLabel(tab, text="آماده به کار...", font=ctk.CTkFont(size=12))
        self.lbl_status.grid(row=4, column=0, columnspan=2, pady=(0, 5))

        self.txt_log = ctk.CTkTextbox(tab, height=110, font=ctk.CTkFont(family="Consolas", size=11))
        self.txt_log.grid(row=5, column=0, columnspan=2, padx=10, pady=5, sticky="nsew")

        res_frame = ctk.CTkFrame(tab, corner_radius=10)
        res_frame.grid(row=6, column=0, columnspan=2, padx=10, pady=5, sticky="nsew")
        res_frame.grid_columnconfigure(0, weight=1)

        self.lbl_result = ctk.CTkLabel(res_frame, text="🔗 دو لینک اتصال؛ پورت‌های آزاد به‌صورت خودکار انتخاب می‌شوند", font=ctk.CTkFont(size=13, weight="bold"))
        self.lbl_result.pack(anchor="w", padx=15, pady=(10, 2))

        self.txt_result = ctk.CTkTextbox(res_frame, height=90, font=ctk.CTkFont(family="Consolas", size=11))
        self.txt_result.pack(fill="x", padx=15, pady=5)

        btn_action_frame = ctk.CTkFrame(res_frame, fg_color="transparent")
        btn_action_frame.pack(fill="x", padx=15, pady=(5, 10))

        self.btn_copy = ctk.CTkButton(
            btn_action_frame, 
            text="📋 کپی لینک اصلی",
            fg_color="#2b8a3e", 
            hover_color="#237032",
            height=35,
            command=self.copy_to_clipboard
        )
        self.btn_copy.pack(side="left", fill="x", expand=True, padx=(0, 5))

        self.btn_copy_second = ctk.CTkButton(
            btn_action_frame, text="📋 کپی لینک دوم", height=35,
            command=self.copy_secondary_to_clipboard,
        )
        self.btn_copy_second.pack(side="left", fill="x", expand=True, padx=5)

        self.btn_qr = ctk.CTkButton(
            btn_action_frame, 
            text="📱 نمایش QR Code", 
            height=35,
            fg_color="#495057",
            hover_color="#343a40",
            command=self.show_qr_code
        )
        self.btn_qr.pack(side="left", fill="x", expand=True, padx=5)

        self.btn_save = ctk.CTkButton(
            btn_action_frame, 
            text="💾 ذخیره در فایل", 
            height=35,
            fg_color="#495057",
            hover_color="#343a40",
            command=self.save_to_txt
        )
        self.btn_save.pack(side="left", fill="x", expand=True, padx=(5, 0))

    def setup_history_tab(self):
        tab = self.tab_history
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(1, weight=1)

        top_frame = ctk.CTkFrame(tab, fg_color="transparent")
        top_frame.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

        lbl_hist = ctk.CTkLabel(top_frame, text="📜 سرورهای ذخیره شده قبلی:", font=ctk.CTkFont(size=16, weight="bold"))
        lbl_hist.pack(side="left")

        btn_clear = ctk.CTkButton(top_frame, text="🗑 پاک کردن تاریخچه", width=120, height=30, fg_color="#c92a2a", hover_color="#a61e1e", command=self.clear_history)
        btn_clear.pack(side="right")

        self.txt_history = ctk.CTkTextbox(tab, font=ctk.CTkFont(family="Consolas", size=12))
        self.txt_history.grid(row=1, column=0, padx=10, pady=5, sticky="nsew")

    def update_method_hint(self, selected):
        hints = {
            "TCP + XHTTP": "یک لینک TCP برای روش فعلی و یک لینک XHTTP برای کلاینت سازگار ساخته می‌شود. پشتیبانی XHTTP در نسخهٔ V2BOX شما باید بررسی شود.",
            "XHTTP + REALITY": "روش جایگزین XHTTP به کلاینت دارای پشتیبانی XHTTP و هستهٔ به‌روز نیاز دارد؛ مانند v2rayNG جدید در اندروید. اتصال از شبکهٔ شما باید جداگانه تست شود.",
            "TCP + REALITY (V2BOX)": "روش TCP/Vision قبلی با بررسی اتصال واقعی. این انتخاب متد XHTTP تولید نمی‌کند.",
        }
        self.lbl_method_hint.configure(text=hints.get(selected, "روش اتصال را از فهرست انتخاب کنید."))

    def toggle_password(self):
        if self.entry_pass.cget("show") == "*":
            self.entry_pass.configure(show="")
            self.btn_show_pass.configure(text="🔒")
        else:
            self.entry_pass.configure(show="*")
            self.btn_show_pass.configure(text="👁")

    def post_ui(self, callback, *args):
        self.ui_queue.put((callback, args))

    def process_ui_queue(self):
        try:
            while True:
                callback, args = self.ui_queue.get_nowait()
                callback(*args)
        except queue.Empty:
            pass
        finally:
            self.after(75, self.process_ui_queue)

    def append_log(self, text):
        self.txt_log.insert("end", text)
        self.txt_log.see("end")

    def set_status(self, text, progress=None):
        def update_status():
            self.lbl_status.configure(text=text)
            if progress is not None:
                self.prog_bar.set(progress)
        self.post_ui(update_status)

    def start_deployment_thread(self):
        if self.is_running:
            return

        ip = self.entry_ip.get().strip()
        port_str = self.entry_port.get().strip()
        user = self.entry_user.get().strip()
        password = self.entry_pass.get()
        sni = self.combo_sni.get().strip()
        name = self.entry_name.get().strip()
        method = CONNECTION_METHODS.get(self.combo_method.get())

        if not ip or not password:
            messagebox.showerror("خطا", "لطفاً آدرس آی‌پی سرور و رمز عبور را وارد کنید.")
            return

        try:
            port = int(port_str)
            if not 1 <= port <= 65535:
                raise ValueError("پورت SSH باید بین ۱ و ۶۵۵۳۵ باشد.")
            ip = normalize_host(ip)
            sni = normalize_host(sni, allow_ip=False)
            user = user or "root"
            name = name or "HighSpeed-Reality"
            if method is None:
                raise ValueError("روش اتصال را از فهرست انتخاب کنید.")
        except ValueError as exc:
            messagebox.showerror("خطا", f"اطلاعات اتصال معتبر نیست:\n{exc}")
            return

        self.is_running = True
        self.btn_start.configure(state="disabled", text="⏳ در حال راه‌اندازی...")
        self.txt_result.delete("1.0", "end")
        self.txt_log.delete("1.0", "end")
        self.lbl_result.configure(text="🔗 در حال بررسی و انتخاب دو پورت آزاد...")
        self.btn_copy.configure(text="📋 کپی لینک اصلی")

        thread = threading.Thread(
            target=self.deploy_worker, 
            args=(ip, port, user, password, sni, name, method),
            daemon=True
        )
        thread.start()

    def deploy_worker(self, ip, port, user, password, sni, name, method="mixed"):
        client = None
        try:
            self.set_status("📡 مرحله ۱ از ۵: اتصال به سرور از طریق SSH...", 0.15)
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            last_err = None
            for attempt in range(4):
                try:
                    self.set_status(f"📡 تلاش {attempt + 1} از ۴ برای اتصال به SSH...", 0.15)
                    client.connect(
                        ip, port=port, username=user, password=password,
                        timeout=20, banner_timeout=60, auth_timeout=30,
                        look_for_keys=False, allow_agent=False,
                    )
                    break
                except paramiko.AuthenticationException as exc:
                    raise RuntimeError("نام کاربری یا رمز SSH پذیرفته نشد. در صورت انقضای رمز، ابتدا آن را از طریق SSH تغییر دهید.") from exc
                except Exception as exc:
                    last_err = exc
                    if attempt < 3:
                        time.sleep(2)
            else:
                raise RuntimeError(f"اتصال SSH با سرور ناموفق بود: {last_err}")

            self.set_status("📦 مرحله ۲ از ۵: بررسی و نصب Xray...", 0.4)
            self.post_ui(self.append_log, "روش انتخاب‌شده: " + method + "\n")
            payload = build_deployment_script(ip, sni, name, port, method=method)
            pending_log = ""
            stages = {
                "preflight": ("📡 بررسی پیش‌نیازهای سرور...", 0.35),
                "dependencies": ("📦 نصب پیش‌نیازها...", 0.4),
                "install": ("📦 مرحله ۲ از ۵: بررسی و نصب Xray...", 0.45),
                "target-check": ("🌐 بررسی TLS 1.3 و سازگاری دامنه SNI با روش انتخاب‌شده...", 0.48),
                "ports": ("🔎 بررسی پورت‌ها و انتخاب دو پورت آزاد...", 0.5),
                "keys": ("🔑 مرحله ۳ از ۵: ساخت کلیدها و کانفیگ...", 0.6),
                "config-test": ("🔎 مرحله ۳ از ۵: بررسی اعتبار کانفیگ...", 0.7),
                "network": ("⚙️ مرحله ۴ از ۵: تنظیم شبکه و پورت‌ها...", 0.8),
                "service": ("🔒 مرحله ۵ از ۵: بررسی فعال بودن سرویس...", 0.9),
                "verification": ("🔎 بررسی پورت‌های سرویس فعال...", 0.95),
                "connection-test": ("🔎 آزمون اتصال REALITY و عبور HTTPS روی هر دو پورت...", 0.97),
            }

            def log_output(text):
                nonlocal pending_log
                pending_log += text
                while "\n" in pending_log:
                    line, pending_log = pending_log.split("\n", 1)
                    if line.startswith("LINK_"):
                        continue
                    self.post_ui(self.append_log, line + "\n")
                    if line.startswith("PORT_SKIPPED="):
                        skipped_port, _, reason = line.partition("=")[2].partition(":")
                        why = {"SSH": "مخصوص SSH است", "permission": "اجازهٔ استفاده ندارد"}.get(reason, "اشغال است")
                        self.post_ui(self.append_log, f"پورت {skipped_port} {why}؛ پورت دیگری انتخاب می‌شود.\n")
                    elif line.startswith("SELECTED_PORTS="):
                        self.post_ui(self.append_log, "پورت‌های انتخاب‌شده: " + line.partition("=")[2] + "\n")
                    if line.startswith("STAGE="):
                        status = stages.get(line.partition("=")[2].strip())
                        if status:
                            self.set_status(*status)

            exit_code, output, err_output = run_remote_script(client, payload, log_output)
            if pending_log and not pending_log.startswith("LINK_"):
                self.post_ui(self.append_log, pending_log + "\n")
            primary_link, secondary_link = parse_deployment_result(exit_code, output, err_output)
            self.set_status("🌐 بررسی دسترسی پورت‌های عمومی از این دستگاه...", 0.99)
            public_checks = probe_public_links((primary_link, secondary_link))
            self.post_ui(self.deployment_succeeded, ip, name, primary_link, secondary_link, sni, public_checks)
        except Exception as exc:
            self.post_ui(self.deployment_failed, str(exc))
        finally:
            try:
                if client is not None:
                    client.close()
            finally:
                self.post_ui(self.deployment_finished)

    def deployment_succeeded(self, ip, name, primary_link, secondary_link, sni, public_checks):
        reachable = [check['port'] for check in public_checks if check['reachable']]
        blocked = [check['port'] for check in public_checks if not check['reachable']]
        if connection_port(primary_link) not in reachable and connection_port(secondary_link) in reachable:
            primary_link, secondary_link = secondary_link, primary_link
        primary_port, secondary_port = connection_port(primary_link), connection_port(secondary_link)
        primary_type = parse_reality_link(primary_link)['transport'].upper()
        secondary_type = parse_reality_link(secondary_link)['transport'].upper()
        if reachable:
            self.lbl_status.configure(text="✅ اتصال REALITY روی سرور بررسی شد؛ پورت قابل‌دسترسی: " + ', '.join(map(str, reachable)))
        else:
            self.lbl_status.configure(text="⚠️ اتصال داخل سرور درست است؛ پورت عمومی از این دستگاه در دسترس نیست.")
        self.lbl_result.configure(text=f"🔗 {primary_type}: پورت {primary_port} | {secondary_type}: پورت {secondary_port}")
        self.btn_copy.configure(text=f"📋 کپی {primary_type} (پورت {primary_port})")
        self.prog_bar.set(1)
        self.txt_result.insert("1.0", f"{primary_link}\n\n{secondary_link}")
        notice = f"اتصال REALITY و عبور HTTPS داخل سرور روی پورت‌های {primary_port} و {secondary_port} بررسی شد."
        reasons = {'timeout': 'مهلت اتصال تمام شد', 'refused': 'اتصال رد شد',
                   'dns': 'نام سرور پیدا نشد', 'network': 'خطای شبکه'}
        for check in public_checks:
            if check['reachable']:
                self.append_log(f"پورت {check['port']} از این دستگاه قابل دسترسی است؛ تأخیر اتصال TCP: {check['latency_ms']} ms.\n")
            else:
                self.append_log(f"پورت {check['port']} از این دستگاه قابل دسترسی نیست: {reasons.get(check['error'], 'خطای شبکه')}.\n")
        self.append_log("تأخیر TCP با پینگ اتصال کامل در V2BOX متفاوت است؛ اتصال نهایی را در همان برنامه بررسی کنید.\n")
        if blocked:
            notice += '\n\nپورت غیرقابل‌دسترسی از این دستگاه: ' + ', '.join(map(str, blocked))
            notice += '\nفایروال پنل VPS، آدرس عمومی سرور و محدودیت شبکهٔ فعلی را بررسی کنید. این تست علت دقیق مسدودی را مشخص نمی‌کند.'
        if reachable:
            notice += '\nپورت قابل‌دسترسی: ' + ', '.join(map(str, reachable))
        if 'XHTTP' in (primary_type, secondary_type):
            notice += "\n\nلینک XHTTP به کلاینت دارای پشتیبانی XHTTP نیاز دارد؛ پشتیبانی نسخهٔ V2BOX شما تأیید نشده است."
            self.append_log("XHTTP بدون جریان Vision ساخته شد؛ مسیر و پارامترهای آن در آزمون واقعی بررسی شدند.\n")
        self.append_log("نتیجهٔ نصب، دسترسی از شبکهٔ همراه اول یا ایرانسل را تأیید نمی‌کند؛ کلاینت روی همان شبکه باید آزمایش شود.\n")
        try:
            pyperclip.copy(primary_link)
            notice += f"\nلینک اصلی پورت {primary_port} در کلیپ‌بورد کپی شد."
        except Exception:
            notice += "\nکپی خودکار انجام نشد؛ لینک را از کادر نتیجه کپی کنید."
        try:
            self.save_to_history_db(ip, name, primary_link, sni)
        except Exception as exc:
            self.append_log(f"ذخیره تاریخچه انجام نشد: {exc}\n")
            notice += "\nذخیره تاریخچه انجام نشد؛ لینک‌ها را در فایل ذخیره کنید."
        notice += "\n\nدر V2BOX لینک تازه را وارد و متصل کنید؛ نصب دوباره لینک‌های قبلی این سرور را نامعتبر می‌کند."
        if blocked:
            messagebox.showwarning("نتیجهٔ بررسی اتصال", notice)
        else:
            messagebox.showinfo("نتیجهٔ بررسی اتصال", notice)

    def deployment_failed(self, details):
        self.lbl_status.configure(text="❌ عملیات کامل نشد؛ جزئیات در کادر گزارش آمده است.")
        self.lbl_result.configure(text="🔗 راه‌اندازی کامل نشد؛ هنوز لینک جدیدی آماده نیست.")
        self.prog_bar.set(0)
        self.append_log("\n" + details + "\n")
        messagebox.showerror("خطا در راه‌اندازی", deployment_error_summary(details) + "\n\nگزارش کامل در کادر گزارش برنامه قابل پیمایش و کپی است.")

    def deployment_finished(self):
        self.is_running = False
        self.btn_start.configure(state="normal", text="🚀 نصب و بررسی اتصال (1-Click Start)")

    def copy_to_clipboard(self):
        text = self.txt_result.get("1.0", "end").strip()
        if text:
            first_line = text.split("\n")[0].strip()
            pyperclip.copy(first_line)
            messagebox.showinfo("کپی شد", f"✅ لینک اصلی پورت {connection_port(first_line)} در کلیپ‌بورد کپی شد.")
        else:
            messagebox.showwarning("خالی", "لینکی برای کپی وجود ندارد.")

    def show_qr_code(self):
        text = self.txt_result.get("1.0", "end").strip()
        if not text:
            messagebox.showwarning("خالی", "ابتدا یک سرور را راه‌اندازی کنید تا لینک ایجاد شود.")
            return

        first_line = text.split("\n")[0].strip()
        qr = qrcode.QRCode(box_size=10, border=2)
        qr.add_data(first_line)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        qr_win = ctk.CTkToplevel(self)
        qr_win.title(f"📱 QR Code - پورت {connection_port(first_line)}")
        qr_win.geometry("380x420")
        qr_win.attributes("-topmost", True)

        ctk_img = ctk.CTkImage(light_image=img.get_image(), dark_image=img.get_image(), size=(320, 320))
        lbl_img = ctk.CTkLabel(qr_win, image=ctk_img, text="")
        lbl_img.pack(padx=20, pady=20)

        lbl_hint = ctk.CTkLabel(qr_win, text="با برنامه v2rayNG در اندروید یا Streisand در iOS اسکن کنید.", font=ctk.CTkFont(size=11))
        lbl_hint.pack(pady=(0, 10))

    def copy_secondary_to_clipboard(self):
        links = [line.strip() for line in self.txt_result.get("1.0", "end").splitlines() if line.strip()]
        if len(links) < 2:
            messagebox.showwarning("خالی", "هنوز لینک دومی برای کپی وجود ندارد.")
            return
        fields = parse_reality_link(links[1])
        pyperclip.copy(links[1])
        messagebox.showinfo("کپی شد", f"لینک {fields['transport'].upper()} پورت {fields['port']} کپی شد.")

    def save_to_txt(self):
        text = self.txt_result.get("1.0", "end").strip()
        if not text:
            messagebox.showwarning("خالی", "لینکی برای ذخیره وجود ندارد.")
            return

        filepath = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            title="ذخیره لینک سرور"
        )
        if filepath:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(text + "\n")
            messagebox.showinfo("ذخیره شد", f"✅ فایل با موفقیت ذخیره شد:\n{filepath}")

    def save_to_history_db(self, ip, name, link, sni):
        data = []
        if os.path.exists(HISTORY_FILE):
            try:
                with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except:
                data = []

        data = [x for x in data if x.get("ip") != ip]

        item = {
            "date": time.strftime("%Y-%m-%d %H:%M:%S"),
            "ip": ip,
            "name": name,
            "sni": sni,
            "link": link
        }
        data.insert(0, item)

        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        self.load_history()

    def load_history(self):
        self.txt_history.delete("1.0", "end")
        if not os.path.exists(HISTORY_FILE):
            self.txt_history.insert("1.0", "هنوز سروری ثبت نشده است.\n")
            return

        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not data:
                self.txt_history.insert("1.0", "هنوز سروری ثبت نشده است.\n")
                return

            for idx, item in enumerate(data, 1):
                block = f"[{idx}] {item.get('name', 'Server')} | IP: {item.get('ip')} | Date: {item.get('date')}\n"
                block += f"SNI: {item.get('sni', 'www.speedtest.net')}\n"
                block += f"Link: {item.get('link')}\n"
                block += "-" * 75 + "\n\n"
                self.txt_history.insert("end", block)
        except Exception as e:
            self.txt_history.insert("1.0", f"خطا در خواندن تاریخچه: {e}\n")

    def clear_history(self):
        if messagebox.askyesno("تأیید", "آیا مطمئن هستید که می‌خواهید کل تاریخچه سرورها پاک شود؟"):
            if os.path.exists(HISTORY_FILE):
                os.remove(HISTORY_FILE)
            self.load_history()

if __name__ == "__main__":
    app = XRayCreatorApp()
    app.mainloop()
